jQuery(function($) {
    if ($('.js-main-slider').length) {
        let mainSlider = new Splide('.js-main-slider', {
            perPage: 1,
            rewind: true,
            type: 'loop',
            autoplay: 'play',
            pagination: false
        });
        mainSlider.mount();
    }
    if ($('.js-hotel-splide').length) {
        let hotelSlider = new Splide('.js-hotel-splide', {
            perPage: 1,
            rewind: true,
            type: 'loop',
            pagination: false
        });
        hotelSlider.mount();
    }

    if ($('.js-rooms-splide').length) {
        let roomsSlider = new Splide('.js-rooms-splide', {
            perPage: perPageCount(),
            rewind: true,
            type: 'loop',
            gap: '1rem',
            clones: 0,
            pagination: false
        });
        roomsSlider.on('resize', function () {
            roomsSlider.options = {
                perPage: perPageCount(),
            };
        });
        roomsSlider.mount();
    }

    if ($('.js-awards-list-splide').length) {
        const arr = []
        $('.js-awards-list-splide').each(function(i) {
            console.log('.js-awards-list-splide-' + i)
            arr.push(new Splide('.js-awards-list-splide-' + i, {
                rewind: true,
                type: 'loop',
                gap: '1rem',
                pagination: false,
                autoWidth: true,
            }));
            arr[i].mount();
        });
    }

    if ($('.js-packages-splide').length) {
        let packagesSlider = new Splide('.js-packages-splide', {
            perPage: perPageCount(),
            rewind: true,
            type: 'loop',
            gap: '1rem',
            pagination: false
        });

        packagesSlider.on('resize', function () {
            packagesSlider.options = {
                perPage: perPageCount(),
            };
        });
        packagesSlider.mount();
    }

    if ($('.js-reviews-splide').length) {
        let reviewsSlider = new Splide('.js-reviews-splide', {
            perPage: perPageCount(),
            rewind: true,
            type: 'loop',
            gap: '1rem',
            clones: 0,
            pagination: false
        });

        reviewsSlider.on('resize', function () {
            reviewsSlider.options = {
                perPage: perPageCount(),
            };
        });
        reviewsSlider.mount();
    }

    if ($('.js-gallery-splide').length) {
        const arrGallery = []

        let extendImages = {
            init: function() {
                $('.js-extend-images > div').eq(0).click(function(){
                    $('.js-gallery-splide .splide__arrow--prev').trigger('click')
                });
                $('.js-extend-images > div').eq(1).click(function(){
                    // $('.js-gallery-splide .splide__arrow--next').trigger('click')
                    $('.js-gallery-splide .splide__arrow--next').trigger('click')
                });
            }
        }
        extendImages.init();

        $('.js-gallery-splide').each(function(i) {
            const jsId = 'js-gallery-splide-' + i
            $(this).addClass(jsId)

            arrGallery.push(
                new Splide('.' + jsId, {
                    perPage: 1,
                    rewind: true,
                    type: 'loop',
                    pagination: false,
                    start: 1
                })
            )
            arrGallery[i].on('moved ready', function (newIndex, prevIndex, destIndex) {
                setTimeout(function() {
                    let indexPrev = null
                    let indexNext = null
                    let indexActive = null
                    for (const x in arrGallery[i].Components.Elements.slides) {
                        if ($(arrGallery[i].Components.Elements.slides[x]).hasClass('is-active')) {
                            indexActive = x*1
                            indexPrev = x*1 - 1
                            indexNext = x*1 + 1
                        }
                    }
                    if (indexActive === 0) {
                        indexPrev = arrGallery[i].Components.Elements.slides.length - 1
                    }
                    if (indexActive === arrGallery[i].Components.Elements.slides.length - 1) {
                        indexNext = 0
                    }

                    $('.js-extend-images > div').eq(0).css('background-image', 'url(' + arrGallery[i].Components.Elements.slides[indexPrev].dataset.img + ')')
                    $('.js-extend-images > div').eq(1).css('background-image', 'url(' + arrGallery[i].Components.Elements.slides[indexNext].dataset.img + ')')
                    $('.' + jsId).closest('.gallery').find('.js-splide-info > div').text((indexActive+1) + '/' + arrGallery[i].Components.Elements.slides.length)
                }, 100);

            });
            arrGallery[i].mount();
        });
    }
});
