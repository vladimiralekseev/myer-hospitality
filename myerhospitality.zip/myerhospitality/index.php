
    <?php include get_template_directory() . '/templates/header.php';?>
    <main>
        <div class="main-block mb-dynamic">
            <div class="container-data">
                <div class="fixed">
                    <div class="row align-items-end">
                        <div class="col-md-7 mb-md-0 mb-4">
                            <div class="sub-title">AWARD WINNING</div>
                            <div class="title">Branson Hospitality</div>
                        </div>
                        <div class="col-md-5 text-md-end">
                            <div class="btns">
                                <div class="d-md-block d-inline">
                                    <a class="btn btn-secondary mt-2">Hotel</a>
                                    <a class="btn btn-secondary mt-2">Dinning</a>
                                </div>
                                <div class="d-md-block d-inline">
                                    <a class="btn btn-secondary mt-2">Real estate</a>
                                    <a class="btn btn-secondary mt-2">Show tickets</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="awards mb-dynamic">
            <div class="fixed">
                <h2><b>Browse Our Award Winning Branson Hotels</b></h2>
                <div class="text mb-4">
                    Our numerous awards and high guest satisfaction reflect our dedication to you. At Myer Hotels in
                    Branson, Missouri, we offer great value and exceptional service. For show tickets, entertainment, or
                    vacation packages, call any of our hotels for the perfect option.
                </div>
                <div class="list mb-4">
                    <div class="item">
                        <div class="mb-1"><img src="img/award-1.jpg" alt=""/></div>
                        <div class="name">1 500 000+</div>
                        <div class="description">happy clients</div>
                    </div>
                    <div class="item">
                        <div class="mb-1"><img src="img/award-2.jpg" alt=""/></div>
                        <div class="name">30 years</div>
                        <div class="description">of ticket experience</div>
                    </div>
                    <div class="item">
                        <div class="mb-1"><img src="img/award-3.jpg" alt=""/></div>
                        <div class="name">55 years</div>
                        <div class="description">of hotel experience</div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-7 col-12 text-lg-start text-center">
                        <img class="mx-2 mb-3" src="img/trip-advisor.png" alt=""/>
                        <img class="mx-2 mb-3" src="img/love-award.png" alt=""/>
                        <img class="mx-2 mb-3" src="img/satisfaction-guaranted.png" alt=""/>
                        <img class="mx-2 mb-3" src="img/award-winning.png" alt=""/>
                    </div>
                    <div class="col-lg-5 col-12">
                        All our hotels are top-rated on Trip Advisor, receiving the Certificate of Excellence for
                        outstanding reviews. Satisfaction guaranteed: if you’re unhappy with any aspect of your stay,
                        we’ll make it right. The Love Thy Neighbor award honors staff for exceptional service and
                        kindness. Our hotels win national awards annually for hospitality, cleanliness, and outstanding
                        service.
                    </div>
                </div>
            </div>
        </div>
        <div class="hotels mb-dynamic">
            <div class="item">
                <div class="fixed">
                    <h2><b>Our hotels</b></h2>
                    <div class="row align-items-center mb-2">
                        <div class="col-md-11 col-12 d-flex justify-content-start align-items-center">
                            <img src="img/bw-logo.png" class="me-3"/> <a class="h4 name" href="#">Best Western Center
                                Point Inn</a>
                        </div>
                        <div class="col-1 d-none d-md-block text-end">
                            <a href="#" class="btn btn-primary btn-small detail"><span
                                        class="icon icon-arrow-right"></span></a>
                        </div>
                    </div>
                </div>
                <div class="img mb-3" style="background-image: url('img/hotel-cpi.jpg')"></div>
                <div class="fixed">
                    <div class="contact">
                        <div class="mb-2">
                            <span class="icon icon-location me-1"></span> 3215 West 76 Country Boulevard, Branson, MO
                            65616
                        </div>
                        <div>
                            <span class="icon icon-phone me-1"></span> <a href="tel:417-335-4731">417-335-4731</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="fixed">
                    <div class="row align-items-center mb-2">
                        <div class="col-md-11 col-12 d-flex justify-content-start align-items-center">
                            <img src="img/sic-logo.png" class="me-3"/> <a class="h4 name" href="#">Comfort Inn & Suites
                                Branson Meadows</a>
                        </div>
                        <div class="col-1 d-none d-md-block text-end">
                            <a href="#" class="btn btn-primary btn-small detail">
                                <span class="icon icon-arrow-right"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="img mb-3" style="background-image: url('img/hotel-cis.jpg')"></div>
                <div class="fixed">
                    <div class="contact">
                        <div class="mb-2">
                            <span class="icon icon-location me-1"></span> 5150 Gretna Road, Branson, MO 65616
                        </div>
                        <div>
                            <span class="icon icon-phone me-1"></span> <a href="tel:417-335-4731">417-335-4731</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="fixed">
                    <div class="row align-items-center mb-2">
                        <div class="col-md-11 col-12 d-flex justify-content-start align-items-center">
                            <img src="img/sic-logo.png" class="me-3"/> <a class="h4 name" href="#">Comfort Inn Thousand
                                Hills</a>
                        </div>
                        <div class="col-1 d-none d-md-block text-end">
                            <a href="#" class="btn btn-primary btn-small detail">
                                <span class="icon icon-arrow-right"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="img mb-3" style="background-image: url('img/hotel-cit.jpg')"></div>
                <div class="fixed">
                    <div class="contact">
                        <div class="mb-2">
                            <span class="icon icon-location me-1"></span> 203 South Wildwood Drive Branson, MO 65616
                        </div>
                        <div>
                            <span class="icon icon-phone me-1"></span> <a href="tel:417-335-4731">417-335-4731</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="fixed">
                    <div class="row align-items-center mb-2">
                        <div class="col-md-11 col-12 d-flex justify-content-start align-items-center">
                            <img src="img/sic-logo.png" class="me-3"/> <a class="h4 name" href="#">Holiday Inn Express
                                Green Mountain Drive</a>
                        </div>
                        <div class="col-1 d-none d-md-block text-end">
                            <a href="#" class="btn btn-primary btn-small detail">
                                <span class="icon icon-arrow-right"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="img mb-3" style="background-image: url('img/hotel-hie.jpg')"></div>
                <div class="fixed">
                    <div class="contact">
                        <div class="mb-2">
                            <span class="icon icon-location me-1"></span> 2801 Green Mountain Drive Branson, MO 65616
                        </div>
                        <div>
                            <span class="icon icon-phone me-1"></span> <a href="tel:417-335-4731">417-335-4731</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-dynamic">
            <img src="img/map.jpg"/>
        </div>
        <div class="fixed">
            <h2><b>We will provide you with the best service</b></h2>
            <div class="services mb-dynamic">
                <div class="it">
                    <img src="img/service-1.jpg" alt="In-house ticket service"/>
                    <div>In-house ticket service</div>
                </div>
                <div class="it">
                    <img src="img/service-2.jpg" alt="More quiet stay"/>
                    <div>More quiet stay</div>
                </div>
                <div class="it">
                    <img src="img/service-3.jpg" alt="Stable management staff"/>
                    <div>Stable management staff</div>
                </div>
                <div class="it">
                    <img src="img/service-4.jpg" alt="Connecting rooms"/>
                    <div>Connecting rooms</div>
                </div>
            </div>
        </div>
        <div class="fixed">
            <h2><b>Branson’s Best Vacation Packages</b></h2>
            <div class="packages-main">
                <div class="it mb-5">
                    <div class="row">
                        <div class="col-md-5 col-12 mb-3"><a href="#"><img
                                        src="https://www.myerhospitality.com/wp-content/uploads/2023/06/World-Class-Family-Entertainment-600x428.jpg"/></a>
                        </div>
                        <div class="col-md-7 col-12 mb-3">
                            <a href="#" class="d-block mb-2 h4"><b>Branson Museum & Attraction Package II</b></a>
                            <div>Save abundantly on an abundance of attractions!</div>
                            <div class="my-lg-4 my-2">
                                <span class="tag">Beyond The Lens Family Fun Branson</span>
                                <span class="tag">Titanic Museum Attraction</span>
                                <span class="tag">Hollywood Wax Museum – Branson</span>
                                <span class="tag">Butterfly Palace</span>
                            </div>
                            <div class=" costs pt-lg-4 pt-2">
                                <div class="row align-items-center row-small-padding">
                                    <div class="col-7">
                                        Save per adult <span class="up-to">up to $25</span>
                                    </div>
                                    <div class="col-5 text-end">
                                        <a href="#" class="btn btn-primary">Book now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="it mb-5">
                    <div class="row">
                        <div class="col-md-5 col-12 mb-3"><a href="#"><img
                                        src="https://www.myerhospitality.com/wp-content/uploads/2023/06/World-Class-Family-Entertainment-600x428.jpg"/></a>
                        </div>
                        <div class="col-md-7 col-12 mb-3">
                            <a href="#" class="d-block mb-2 h4"><b>Branson Museum & Attraction Package II</b></a>
                            <div>Save abundantly on an abundance of attractions!</div>
                            <div class="my-lg-4 my-2">
                                <span class="tag">Beyond The Lens Family Fun Branson</span>
                                <span class="tag">Titanic Museum Attraction</span>
                                <span class="tag">Hollywood Wax Museum – Branson</span>
                                <span class="tag">Butterfly Palace</span>
                            </div>
                            <div class=" costs pt-lg-4 pt-2">
                                <div class="row align-items-center row-small-padding">
                                    <div class="col-7">
                                        Save per adult <span class="up-to">up to $25</span>
                                    </div>
                                    <div class="col-5 text-end">
                                        <a href="#" class="btn btn-primary">Book now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="packages-main-more mb-dynamic">
            <a class="btn btn-third">View 10 more</a>
        </div>

        <div class="fixed">
            <h2><b>Branson’s Best Free Guides</b></h2>
            <div class="guides mb-dynamic">
                <div class="it">
                    <a href="#"><img src="img/guides-1.jpg" alt="In-house ticket service"/></a>
                    <a href="#" class="h4 name mb-2">The Flavor of Branson</a>
                    <div class="description mb-2">The Flavor of Branson is the only area publication dedicated to
                        showcasing
                        the diverse and
                        fabulous restaurants of Branson.
                    </div>
                    <a href="#" class="btn btn btn-third">View guide</a>
                </div>
                <div class="it">
                    <a href="#"><img src="img/guides-2.jpg" alt="More quiet stay"/></a>
                    <a href="#" class="h4 name mb-2">The Taste of Branson</a>
                    <div class="description mb-2">The Taste of Branson is an in-room menu publication found in over
                        10,000 hotel rooms across the Ozarks, featuring menu highlights and detailed restaurant
                        descriptions to guide guests to the best dining spots in Branson
                    </div>
                    <a href="#" class="btn btn btn-third">View guide</a>
                </div>
                <div class="it">
                    <a href="#"><img src="img/guides-3.jpg" alt="Stable management staff"/></a>
                    <a href="#" class="h4 name mb-2">BransonRestaurants.com</a>
                    <div class="description mb-2">Created to give locals and tourists to Branson, MO, the most
                        accurate restaurant information online.
                    </div>
                    <a href="#" class="btn btn btn-third">View guide</a>
                </div>
            </div>
        </div>

        <img src="img/guys.jpg" class="w-100 mb-dynamic"/>

        <div class="e-club mb-dynamic">
            <div class="fixed">
                <h2><b>Save <span class="discount">15% off</span> your next stay by joining our E-Club</b></h2>
            </div>
        </div>

        <div class="fixed">
            <div class="small-hotels mb-dynamic">
                <div class="it">
                    <a href="#"><img src="img/hotel-s-1.jpg" alt="In-house ticket service"/></a>
                    <a href="#" class="h5 name mb-2">Best Western Center Pointe Inn</a>
                    <div class="btns">
                        <a href="#" class="btn btn btn-third">417-335-4731</a>
                    </div>
                </div>
                <div class="it">
                    <a href="#"><img src="img/hotel-s-2.jpg" alt="More quiet stay"/></a>
                    <a href="#" class="h5 name mb-2">Comfort Inn & Suites Branson Meadows</a>
                    <div class="btns">
                        <a href="#" class="btn btn btn-third">417-335-4731</a>
                    </div>
                </div>
                <div class="it">
                    <a href="#"><img src="img/hotel-s-3.jpg" alt="Stable management staff"/></a>
                    <a href="#" class="h5 name mb-2">Comfort Inn Thousand Hills</a>
                    <div class="btns">
                        <a href="#" class="btn btn btn-third">417-336-2100</a>
                    </div>
                </div>
                <div class="it">
                    <a href="#"><img src="img/hotel-s-4.jpg" alt="Stable management staff"/></a>
                    <a href="#" class="h5 name mb-2">Holiday Inn Express Green Mountain Drive</a>
                    <div class="btns">
                        <a href="#" class="btn btn btn-third">417-336-2100</a>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php include get_template_directory() . '/templates/footer.php';?>
