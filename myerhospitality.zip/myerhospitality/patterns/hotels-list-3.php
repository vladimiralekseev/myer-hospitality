<?php
/**
 * Title: Hotels List 3
 * Slug: myerhospitality/hotels-list-3
 * Categories: query, posts
 * Block Types: Hotels List 3
 */

$args = [
    'posts_per_page' => 4,
    'post_type'      => 'hotel',
];
$posts = get_posts($args);
?>

<?php if ($posts) { ?>
    <div class="fixed">
        <h4 class="h4 blue">Hotel Fact Sheets</h4>
        <div class="small-hotels mb-dynamic">
            <?php foreach ($posts as $post) { ?>
                <?php $link = get_permalink($post->ID) ?>
                <?php $ticketsUrl = get_post_meta($post->ID, 'tickets_url', true) ?>
                <?php $address = get_post_meta($post->ID, 'address', true) ?>
                <?php $image = wp_get_attachment_image_src(
                    get_post_meta($post->ID, 'preview_image', true),
                    'single-post-thumbnail'
                ); ?>
                <div class="it">
                    <?php if ($image) { ?>
                        <a href="<?= $link ?>"><img src="<?= $image[0] ?>" alt="<?= $post->post_title ?>"/></a>
                    <?php } ?>
                    <a href="<?= $link ?>" class="h5 name mb-2"><?= $post->post_title ?></a>
                    <?php if ($address) { ?>
                        <div><?= $address ?></div>
                    <?php } ?>
                    <?php if ($ticketsUrl) { ?>
                        <div class="btns">
                            <a href="<?= $ticketsUrl ?>" class="btn btn btn-third">View the website</a>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
    </div>
<?php } ?>
