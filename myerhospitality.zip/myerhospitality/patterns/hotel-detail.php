<?php
/**
 * Title: Hotel Detail
 * Slug: myerhospitality/hotel-detail
 * Categories: query, posts
 * Block Types: Hotel Detail
 */

global $post;

$title = get_post_meta($post->ID, 'title', true);
$address = get_post_meta($post->ID, 'address', true);
$phoneNumber = get_post_meta($post->ID, 'phone_number', true);
$amenitiesDescription = get_post_meta($post->ID, 'amenities_description', true);
$meetingFacilities = get_post_meta($post->ID, 'meeting_facilities', true);
$ourLocation = get_post_meta($post->ID, 'our_location', true);
$ticketsUrl = get_post_meta($post->ID, 'tickets_url', true);
$packageUrl = get_post_meta($post->ID, 'package_url', true);
$meetingFacilityImage = wp_get_attachment_url(get_post_meta($post->ID, 'meeting_facility_image', true));

$tags = get_the_tags($post);
$tags = $tags ? array_map(
    function ($el) {
        return $el->name;
    },
    $tags
) : [];
$imageIds = get_post_meta($post->ID, 'images', true);
$bigImageIds = get_post_meta($post->ID, 'big_images', true);
$bigLogo = wp_get_attachment_url(get_post_meta($post->ID, 'big_logo', true));

$packages = get_posts(
    [
        'post_type'      => 'packages',
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        'posts_per_page' => -1,
    ]
);
$images = get_posts(
    [
        'post_type' => 'attachment',
        'include'   => explode(',', $imageIds),
        'orderby'   => 'post__in',
    ]
);
$bigImages = get_posts(
    [
        'post_type' => 'attachment',
        'include'   => explode(',', $bigImageIds),
        'orderby'   => 'post__in',
    ]
);
$arTerms = [];
foreach ($images as $image) {
    $terms = array_map(
        function ($el) {
            return $el->name;
        },
        get_terms(['object_ids' => $image->ID])
    );
    $x = array_merge($arTerms, $terms);
    $arTerms = $x;
}
$arTerms = array_count_values($arTerms);

$arAwards = [];
$awards = get_posts(
    [
        'post_type'      => 'awards',
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        'posts_per_page' => -1,
    ]
);
foreach ($awards as $award) {
    $hotels = get_post_meta($award->ID, 'hotels', true);
    foreach ($hotels as $hotelId) {
        $arAwards[$hotelId][] = $award;
    }
}
$rooms = get_posts(
    [
        'post_type'      => 'rooms',
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        'posts_per_page' => -1,
    ]
);
$arRooms = [];
foreach ($rooms as $room) {
    $hotelId = get_post_meta($room->ID, 'hotel', true);
    if ($post->ID === (int)$hotelId) {
        $arRooms[] = $room;
    }
}

$reviews = get_posts(
    [
        'post_type'      => 'reviews',
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        'posts_per_page' => -1,
    ]
);
$arReviews = [];
foreach ($reviews as $review) {
    $hotelId = get_post_meta($review->ID, 'reviews_hotel', true);
    if ($post->ID === (int)$hotelId) {
        $arReviews[] = $review;
    }
}
?>
<?php if ($bigImages) { ?>
    <div class="hotel-main-slider mb-dynamic">
        <div class="splide js-hotel-splide mb-3">
            <div class="splide__track">
                <ul class="splide__list">
                    <?php foreach ($bigImages as $bigImage) { ?>
                        <li class="splide__slide">
                            <div class="img" style="background-image:url('<?= $bigImage->guid ?>')">
                                <div class="container-data"></div>
                            </div>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <div class="fixed">
            <div class="h1">
                <b><?= $post->post_title ?></b>
            </div>
        </div>
    </div>
<?php } ?>
<?php include "reserve-room.php";?>

<div class="hotel-description mb-dynamic">
    <div class="fixed">
        <?php if ($bigLogo) { ?>
            <div class="mb-4"><img src="<?= $bigLogo ?>"/></div>
        <?php } ?>
        <?php if ($title) { ?>
            <h2 class="mb-4"><b><?= $title ?></b></h2>
        <?php } ?>
        <div class="row mb-4">
            <div class="col-lg-6">
                <div class="mb-4">
                    <?= get_the_excerpt($post) ?>
                    <?php //= $post->post_content ?>
                </div>
                <?php if ($address || $phoneNumber) { ?>
                    <div class="contact mb-4">
                        <?php if ($address) { ?>
                            <div class="mb-2">
                                <span class="icon icon-location me-1"></span> <?= $address ?>
                            </div>
                        <?php } ?>
                        <?php if ($phoneNumber) { ?>
                            <div>
                                <span class="icon icon-phone me-1"></span> <a
                                        href="tel:<?= $phoneNumber ?>"><?= $phoneNumber ?></a>
                            </div>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
            <?php if ($arAwards[$post->ID]) { ?>
                <div class="col-lg-6 text-lg-end text-center">
                    <?php foreach ($arAwards[$post->ID] as $i => $award) { ?>
                        <?php if ($i < 4) { ?>
                            <?php $image = wp_get_attachment_image_src(
                                get_post_thumbnail_id($award->ID),
                                [100, 100]
                            ); ?>
                            <img class="m-1" src="<?= $image[0] ?>"/>
                        <?php } ?>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php if ($amenitiesDescription || $tags) { ?>
    <div class="hotel-amenities mb-dynamic">
        <div class="fixed">
            <div class="row">
                <div class="col-md-4 col-12 mb-3">
                    <div class="h2"><b>Hotel Amenities</b></div>
                    <div><?= $amenitiesDescription ?></div>
                </div>
                <div class="col-md-8 col-12 text-md-end">
                    <?php if ($tags) { ?>
                        <?php foreach ($tags as $tag) { ?>
                            <span class="el-tag el-tag-white"><?= $tag ?></span>
                        <?php } ?>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<?php if ($images) { ?>
    <div class="fixed">
        <div class="gallery mb-dynamic">
            <h2><b>Gallery</b></h2>
            <div class="g-navigation mb-3 d-none">
                <a href="#" class="btn btn-primary me-1">View All Gallery</a>
                <?php foreach ($arTerms as $term => $count) { ?>
                    <a href="#" class="btn btn-secondary me-1"><?= $term ?> (<?= $count ?>)</a>
                <?php } ?>
            </div>
            <div class="row row-small-padding">
                <div class="col-lg-9 col-12">
                    <div class="splide js-gallery-splide">
                        <div class="splide__track">
                            <ul class="splide__list">
                                <?php foreach ($images as $image) { ?>
                                    <?php $terms = array_map(
                                        function ($el) {
                                            return $el->name;
                                        },
                                        get_terms(['object_ids' => $image->ID])
                                    ); ?>
                                    <li class="splide__slide" data-img="<?= $image->guid ?>">
                                        <div class="img" style="background-image:url('<?= $image->guid ?>')">
                                            <div class="container-data">
                                                <img src="<?= $image->guid ?>"/>
                                            </div>
                                        </div>
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                    <div class="splide-info js-splide-info">
                        <div>1/1</div>
                    </div>
                </div>
                <div class="col-3 d-lg-block d-none">
                    <div class="extend-images js-extend-images">
                        <div></div>
                        <div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<div class="fixed">
    <?php if ($arRooms) { ?>
        <div class="rooms mb-4">
            <h2><b>Rooms</b></h2>
            <div class="general-slide splide js-rooms-splide splide-nav-up-right">
                <div class="splide__track">
                    <ul class="splide__list">
                        <?php foreach ($arRooms as $room) { ?>
                            <?php $guests = get_post_meta($room->ID, 'guests', true); ?>
                            <?php $image = wp_get_attachment_image_src(
                                get_post_thumbnail_id($room->ID),
                                [360, 174]
                            ); ?>
                            <li class="splide__slide" data-img="img/hotel-cpi.jpg">
                                <?php if (!empty($image[0])) { ?>
                                    <div class="img" style="background-image:url('<?= $image[0] ?>')">
                                        <img src="<?= $image[0] ?>"/>
                                    </div>
                                <?php } ?>
                                <?php if (!empty($room->post_title)) { ?>
                                    <div class="name"><?= $room->post_title ?></div>
                                <?php } ?>
                                <?php if (!empty($room->post_content)) { ?>
                                    <div class="description"><?= $room->post_content ?></div>
                                <?php } ?>
                                <?php if (!empty($guests)) { ?>
                                    <div class="guests">Guests: <span class="up-to">up to <?= $guests ?></span></div>
                                <?php } ?>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
    <?php } ?>
    <div class="hotel-amenities-list mb-dynamic">
        <div class="title">Room Amenities</div>
        <ul>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/toiletries.svg"/> Toiletries</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/alarm.svg"/> Alarm clock radio</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/channel.svg"/> Cable/movie channels</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/call.svg"/> Free local calls</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/wifi.svg"/> Free Wi-Fi</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/refrigerator.svg"/> Refrigerator</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/microwave.svg"/> Microwave</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/lock.svg"/> Electronic locks</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/viewfinder.svg"/> Viewfinder</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/iron.svg"/> Iron & ironing board</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/coffee.svg"/> Coffee maker</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/hair-dryer.svg"/> Hair dryer</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/table.svg"/> Activity table</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/safety-latch.svg"/> Safety latch</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/sitting-area.svg"/> Sitting area</li>
            <li><img src="/wp-content/themes/myerhospitality/assets/img/icons/iconoir_house-rooms.svg"/> Adjoining rooms, double vanities</li>
        </ul>
    </div>
</div>
<?php if ($meetingFacilities || !empty($meetingFacilityImage)) { ?>
    <div class="meeting-facilities mb-dynamic">
        <div class="fixed">
            <div class="row">
                <div class="col-md-6 mb-3 mb-md-0"><?= $meetingFacilities ?></div>
                <div class="col-md-6 text-md-end">
                    <?php if (!empty($meetingFacilityImage)) { ?>
                        <img class="border-radius" src="<?= $meetingFacilityImage ?>"/>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<div class="fixed">
    <div class="tickets-packages">
        <div class="row mb-3">
            <div class="col-xl-5">
                <h2><b>Tickets & Packages</b></h2>
                Explore tickets and packages from this award-winning hotel. Discover a variety of available
                options and choose the perfect one for your ideal vacation.
            </div>
        </div>
        <?php if ($ticketsUrl) { ?>
        <div class="ticket-banner mb-dynamic">
            <h2>Tickets</h2>
            <div class="mb-3">Don't miss out – your adventure starts here!</div>
            <a href="<?= $ticketsUrl ?>" target="_blank" class="btn btn-secondary px-5">Explore more</a>
        </div>
        <?php } ?>
        <?php if ($packages) { ?>
            <?php if ($packageUrl) { ?>
                <a href="<?= $packageUrl ?>" class="btn btn-third packages-explore-more" target="_blank">
                    Explore more
                </a>
            <?php } ?>
            <div class="h4 mb-3"><a href="#"><b>Packages</b></a></div>
            <div class="general-slide splide js-packages-splide splide-nav-up-right mb-dynamic">
                <div class="splide__track">
                    <ul class="splide__list">
                        <?php foreach ($packages as $package) { ?>
                            <?php $image = wp_get_attachment_image_src(
                                get_post_thumbnail_id($package->ID),
                                'medium'
                            ); ?>
                            <?php $url = get_post_meta($package->ID, 'url', true) ?>
                            <?php $saveUpTo = get_post_meta($package->ID, 'save_up_to', true) ?>
                            <li class="splide__slide">
                                <a href="<?= $url ?>" class="img d-block"
                                   style="background-image:url('<?= $image[0] ?>')">
                                    <img src="<?= $image[0] ?>"/>
                                </a>
                                <?php if ($package->post_title) { ?>
                                    <div class="name"><?= $package->post_title ?></div>
                                <?php } ?>
                                <?php if ($saveUpTo) { ?>
                                    <div class="guests">
                                        Save per adult: <span class="up-to">up to <?= $saveUpTo ?></span>
                                    </div>
                                <?php } ?>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
<div class="join-e-club text-center mb-dynamic">
    <div class="fixed">
        <h2>Join Our E-Club</h2>
        <div class="mb-3">Save 15% off of your next stay when you sign up now!</div>
        <a href="/" class="btn btn-secondary px-5">Sign up</a>
    </div>
</div>
<?php if ($arReviews) { ?>
    <div class="fixed">
        <div class="reviews">
            <h2><b>Customer Reviews</b></h2>
            <div class="reviews-slide splide js-reviews-splide splide-nav-up-right mb-dynamic">
                <div class="splide__track">
                    <ul class="splide__list">
                        <?php foreach ($arReviews as $review) { ?>
                            <?php $image = wp_get_attachment_image_src(
                                get_post_thumbnail_id($review->ID),
                                [100, 100]
                            ); ?>
                            <?php $date = new DateTime($review->post_date); ?>
                            <li class="splide__slide">
                                <?php if ($date) { ?>
                                    <div class="date">Date of stay: <?= $date->format('M Y') ?></div>
                                <?php } ?>
                                <?php if (!empty($review->post_content)) { ?>
                                    <div class="comment"><?= $review->post_content ?></div>
                                <?php } ?>
                                <?php if ($review->post_title) { ?>
                                    <div class="user">
                                        <?php if (!empty($image[0])) { ?>
                                            <img src="<?= $image[0] ?>"/>
                                        <?php } ?>
                                        <?= $review->post_title ?>
                                    </div>
                                <?php } ?>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
<div class="fixed">
    <div class="row mb-dynamic">
        <div class="col-md-5 col-12 mb-3">
            <h2><b>Our location</b></h2>
            <?php if ($ourLocation) { ?>
                <div class="mb-2"><?= $ourLocation ?></div>
            <?php } ?>
            <?php if ($address) { ?>
                <div>
                    <span class="icon icon-location green"></span>
                    <b><?= $address ?></b>
                </div>
            <?php } ?>
        </div>
        <div class="col-xl-6 col-md-7 col-12 offset-xl-1 mb-3">
            <img src="/wp-content/themes/myerhospitality/assets/img/map.png" class="w-100 border-radius"/>
        </div>
    </div>
</div>
