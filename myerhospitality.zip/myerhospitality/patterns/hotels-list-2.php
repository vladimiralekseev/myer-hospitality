<?php
/**
 * Title: Hotels List 2
 * Slug: myerhospitality/hotels-list-2
 * Categories: query, posts
 * Block Types: Hotels List 2
 */

$args = [
    'posts_per_page' => 4,
    'post_type'      => 'hotel',
];
$posts = get_posts($args);
?>

<div class="fixed">
    <div class="mb-dynamic">
        <h2 class="mb-md-5"><b>Select A Property To Shop Tickets Or Vacation Packages!</b></h2>
        <div class="small-hotels small-hotels-extra mb-dynamic">
            <?php foreach ($posts as $post) { ?>
                <?php $link = get_permalink($post->ID) ?>
                <?php $phoneNumber = get_post_meta($post->ID, 'phone_number', true) ?>
                <?php $ticketsUrl = get_post_meta($post->ID, 'tickets_url', true) ?>
                <?php $address = get_post_meta($post->ID, 'address', true) ?>
                <?php $image = wp_get_attachment_image_src(
                    get_post_meta($post->ID, 'preview_image', true),
                    'single-post-thumbnail'
                ); ?>
                <div class="it">
                    <?php if ($image) { ?>
                        <a href="<?= $link ?>"><img src="<?= $image[0] ?>" alt="<?= $post->post_title ?>"/></a>
                    <?php } ?>
                    <a href="<?= $link ?>" class="h6 name mb-2"><?= $post->post_title ?></a>
                    <?php if ($address) { ?>
                        <div class="mb-2"><?= $address ?></div>
                    <?php } ?>
                    <?php if ($phoneNumber || $ticketsUrl) { ?>
                    <div class="btns">
                        <?php if ($ticketsUrl) { ?>
                            <a href="<?= $ticketsUrl ?>" target="_blank" class="btn btn btn-primary">Search now</a>
                        <?php } ?>
                        <?php if ($phoneNumber) { ?>
                            <a href="tel:<?= $phoneNumber ?>" class="btn btn btn-third"><?= $phoneNumber ?></a>
                        <?php } ?>
                    </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
