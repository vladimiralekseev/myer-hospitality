<?php
/**
 * Title: Guides
 * Slug: myerhospitality/home-guides
 * Categories: query, posts
 * Block Types: Guides
 */

$args = [
    'post_type'      => 'guides',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
if ($posts) { ?>
    <div class="fixed">
        <h2><b>Branson’s Best Free Guides</b></h2>
        <div class="guides mb-dynamic">
            <?php foreach ($posts as $i => $post) { ?>
                <?php $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), [674, 480]); ?>
                <div class="it">
                    <?php if ($image) { ?>
                        <a href="#"><img src="<?= $image[0] ?>" alt="In-house ticket service"/></a>
                    <?php } ?>
                    <a href="#" class="h4 name mb-2"><?= $post->post_title ?></a>
                    <div class="description mb-2"><?= $post->post_content ?></div>
                    <a href="#" class="btn btn btn-third">View guide</a>
                </div>
            <?php } ?>
        </div>
    </div>
<?php } ?>
