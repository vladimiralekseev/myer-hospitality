<?php
/**
 * Title: Press Room
 * Slug: myerhospitality/press-room
 * Categories: query, posts
 * Block Types: Press Room
 */

$args = [
    'post_type'      => 'press-room',
    'orderby'        => 'date',
    'order'          => 'DESC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
$arrReleases = [];
if ($posts) {
    foreach ($posts as $i => $post) {
        $date = new DateTime($post->post_date);
        if (empty($arrReleases[$date->format('Y')])) {
            $arrReleases[$date->format('Y')] = [];
        }
        $arrReleases[$date->format('Y')][] = $post;
    }
} ?>
<?php if ($arrReleases) { ?>
    <div class="mb-dynamic">
        <div class="nav-press-room">
            <div class="fixed">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <?php $active = true; ?>
                    <?php foreach ($arrReleases as $year => $posts) { ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?= $active ? 'active' : '' ?>"
                                    id="press-<?= $year ?>-tab"
                                    data-bs-toggle="tab"
                                    data-bs-target="#press-<?= $year ?>"
                                    type="button" role="tab" aria-controls="press-<?= $year ?>"
                                    aria-selected="true"><?= $year ?>
                            </button>
                        </li>
                        <?php $active = false; ?>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <div class="fixed">
            <div class="tab-content" id="myTabContent">
                <?php $active = true; ?>
                <?php foreach ($arrReleases as $year => $posts) { ?>
                    <div class="tab-pane fade show <?= $active ? 'active' : '' ?>" id="press-<?= $year ?>"
                         role="tabpanel" aria-labelledby="press-<?= $year ?>-tab">
                        <div class="press-list">
                            <?php foreach ($posts as $post) {
                                $file = wp_get_attachment_url(get_post_meta($post->ID, 'file', true));
                                $link = $file ?: get_permalink($post->ID);
                                $date = new DateTime($post->post_date);
                                ?>
                                <a class="it" href="<?= $link ?>" <?= $file ? 'target="_blank"' : '' ?>>
                                    <div class="date"><?= $date->format('F d, Y') ?></div>
                                    <div class="title"><?= $post->post_title ?></div>
                                </a>
                            <?php } ?>
                        </div>
                    </div>
                    <?php $active = false; ?>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
