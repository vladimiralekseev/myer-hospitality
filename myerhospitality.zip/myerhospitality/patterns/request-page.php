<?php
/**
 * Title: Request Page
 * Slug: myerhospitality/request-page
 * Categories: query, posts
 * Block Types: Request Page
 */

/** @var WP_Post $post */
$post = get_post();
$youtubeEmbedLink = get_post_meta($post->ID, 'youtube_embed_link', true);
$image = wp_get_attachment_image_src(
    get_post_thumbnail_id($post->ID),
    'single-post-thumbnail'
);
?>
<div class="fixed">
    <div class="mb-4"><?= do_shortcode("[breadcrumb]") ?></div>
    <?php if ($image) { ?>
        <img class="page-img mb-4 ms-md-5" src="<?= $image[0] ?>" alt="<?php the_title(); ?>"/>
    <?php } ?>
    <h1 class="blue my-4">
        <b><?php the_title(); ?></b>
    </h1>
</div>
<?php wp_nav_menu(['theme_location' => 'request-menu', 'menu_class' => 'request-menu']); ?>
<div class="bg-gray-light py-4 mb-dynamic">
<div class="fixed">
<?php the_content(); ?>
</div>
</div>

