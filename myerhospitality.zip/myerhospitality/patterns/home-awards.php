<?php
/**
 * Title: Home Awards
 * Slug: myerhospitality/home-awards
 * Categories: query, posts
 * Block Types: Awards
 */
?>
<div class="main-block mb-dynamic">
    <div class="container-data">
        <div class="fixed">
            <div class="row align-items-end">
                <div class="col-md-7 mb-md-0 mb-4">
                    <div class="sub-title">AWARD WINNING</div>
                    <div class="title">Branson Hospitality</div>
                </div>
                <div class="col-md-5 text-md-end">
                    <div class="btns">
                        <div class="d-md-block d-inline">
                            <a class="btn btn-secondary mt-2">Hotel</a>
                            <a class="btn btn-secondary mt-2">Dinning</a>
                        </div>
                        <div class="d-md-block d-inline">
                            <a class="btn btn-secondary mt-2">Real estate</a>
                            <a class="btn btn-secondary mt-2">Show tickets</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="awards mb-dynamic">
    <div class="fixed">
        <h2><b>Browse Our Award Winning Branson Hotels</b></h2>
        <div class="text mb-4">
            Our numerous awards and high guest satisfaction reflect our dedication to you. At Myer Hotels in
            Branson, Missouri, we offer great value and exceptional service. For show tickets, entertainment, or
            vacation packages, call any of our hotels for the perfect option.
        </div>
        <div class="list mb-4">
            <div class="item">
                <div class="mb-1"><img src="/wp-content/themes/myerhospitality/assets/img/award-1.jpg" alt=""/></div>
                <div class="name">1 500 000+</div>
                <div class="description">happy clients</div>
            </div>
            <div class="item">
                <div class="mb-1"><img src="/wp-content/themes/myerhospitality/assets/img/award-2.jpg" alt=""/></div>
                <div class="name">30 years</div>
                <div class="description">of ticket experience</div>
            </div>
            <div class="item">
                <div class="mb-1"><img src="/wp-content/themes/myerhospitality/assets/img/award-3.jpg" alt=""/></div>
                <div class="name">55 years</div>
                <div class="description">of hotel experience</div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-7 col-12 text-lg-start text-center">
                <img class="mx-2 mb-3" src="/wp-content/themes/myerhospitality/assets/img/trip-advisor.png" alt=""/>
                <img class="mx-2 mb-3" src="/wp-content/themes/myerhospitality/assets/img/love-award.png" alt=""/>
                <img class="mx-2 mb-3" src="/wp-content/themes/myerhospitality/assets/img/satisfaction-guaranted.png" alt=""/>
                <img class="mx-2 mb-3" src="/wp-content/themes/myerhospitality/assets/img/award-winning.png" alt=""/>
            </div>
            <div class="col-lg-5 col-12">
                All our hotels are top-rated on Trip Advisor, receiving the Certificate of Excellence for
                outstanding reviews. Satisfaction guaranteed: if you’re unhappy with any aspect of your stay,
                we’ll make it right. The Love Thy Neighbor award honors staff for exceptional service and
                kindness. Our hotels win national awards annually for hospitality, cleanliness, and outstanding
                service.
            </div>
        </div>
    </div>
</div>
