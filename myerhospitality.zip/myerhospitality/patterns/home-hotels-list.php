<?php
/**
 * Title: Hotels Home List
 * Slug: myerhospitality/home-hotels-list
 * Categories: query, posts
 * Block Types: Hotel
 */

$args = [
//    'posts_per_page' => 4,
    'posts_per_page' => -1,
    'post_type'      => 'hotel',
];
$posts = get_posts($args);
?>


    <div class="hotels mb-dynamic">
        <?php foreach ($posts as $i => $post) { ?>
            <?php $link = get_permalink($post->ID) ?>
            <?php $phoneNumber = get_post_meta($post->ID, 'phone_number', true) ?>
            <?php $address = get_post_meta($post->ID, 'address', true) ?>
            <?php $image = wp_get_attachment_image_src(
                get_post_thumbnail_id($post->ID),
                'single-post-thumbnail'
            ); ?>
            <?php $smallLogo = wp_get_attachment_image_src(
                get_post_meta($post->ID, 'small_logo', true),
                'single-post-thumbnail'
            ); ?>

            <div class="item">
                <div class="fixed">
                    <?php if ($i === 0) { ?><h2><b>Our hotels</b></h2><?php } ?>
                    <div class="row align-items-center mb-2">
                        <div class="col-md-11 col-12 d-flex justify-content-start align-items-center">
                            <?php if ($smallLogo) { ?>
                                <img src="<?= $smallLogo[0] ?>" class="me-3"/>
                            <?php } ?>
                            <a class="h4 name" href="<?= $link ?>"><?= $post->post_title ?></a>
                        </div>
                        <div class="col-1 d-none d-md-block text-end">
                            <a href="<?= $link ?>" class="btn btn-primary btn-small detail">
                                <span class="icon icon-arrow-right"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="img mb-3"
                     <?php if ($image) { ?>style="background-image: url('<?= $image[0] ?>')"<?php } ?>></div>
                <div class="fixed">
                    <div class="contact">
                        <div class="mb-2">
                            <span class="icon icon-location me-1"></span> <?= $address ?>
                        </div>
                        <?php if ($phoneNumber) { ?>
                            <div>
                                <span class="icon icon-phone me-1"></span> <a
                                        href="tel:<?= $phoneNumber ?>"><?= $phoneNumber ?></a>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
<?php
wp_reset_postdata();

