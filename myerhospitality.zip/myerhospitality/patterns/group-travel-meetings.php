<?php

/**
 * Title: Group Travel Meetings
 * Slug: myerhospitality/group-travel-meetings
 * Categories: query, posts
 * Block Types: roup Travel Meetings
 */

?>

<!-- wp:pattern {"slug":"myerhospitality/group-travel"} /-->

<div class="fixed">
    <h2>Group benefits</h2>
    <div class="row mb-dynamic">
        <div class="col-md-6 mb-3">
            <div class="green"><b>Exterior Details:</b></div>
            <ul class="style style-icon">
                <li><span class="icon icon-food-24 green"></span> Free hot breakfast</li>
                <li><span class="icon icon-parking green"></span> Convenient, level and secure parking</li>
                <li><span class="icon icon-door-open-rounded green"></span> Interior Entrances</li>
                <li><span class="icon icon-countertop green"></span> Two sink vanities</li>
                <li><span class="icon icon-hair-dryer green"></span> In-room coffee makers, hair dryers, irons &
                    ironing boards
                </li>
                <li><span class="icon icon-refrigerator green"></span> In-room microwaves and refrigerators</li>
                <li><span class="icon icon-construction green"></span> Concrete construction</li>
                <li><span class="icon icon-luggage green"></span> Luggage service and pre-registration</li>
                <li><span class="icon icon-family-room green"></span> Meeting room and/or enclosed breakfast rooms
                </li>
                <li><span class="icon icon-award-trophy green"></span> Industry Affiliations and Awards</li>
                <li><span class="icon icon-round-room-service green"></span> Large breakfast rooms</li>
            </ul>
        </div>
        <div class="col-md-6 mb-3">
            <div class="green"><b>Benefit:</b></div>
            <ul class="style">
                <li>Reduce trip costs</li>
                <li>Easy for buses to access hotel when unloading and loading guests</li>
                <li>Safe and secure for youth groups and single travelers</li>
                <li>Your group can be ready quicker for the early morning activities</li>
                <li>Packing less for your trip, but all the comforts of home</li>
                <li>Storing and cooking of snacks or storage of medications</li>
                <li>Peaceful, safe and quiet sleep</li>
                <li>Expedited check in process</li>
                <li>Gathering for social time, registration for reunions or team meetings</li>
                <li>Provides confidence of the hospitality we can deliver</li>
                <li>Ensuring groups to eat and get to their first morning activity</li>
            </ul>
        </div>
    </div>
</div>

<div class="fixed mb-dynamic">
    <h2>Pricing for Groups</h2>
    <div class="pricing-groups">
        <div class="it">
            <div class="h4 blue"><b>1</b></div>
            <div>Group rates may not be valid on holidays and special event weekends.</div>
        </div>
        <div class="it">
            <div class="h4 blue"><b>2</b></div>
            <div>Prices are valid for one to four people per room.</div>
        </div>
        <div class="it">
            <div class="h4 blue"><b>3</b></div>
            <div>Group pricing is available for 5 rooms or more.</div>
        </div>
        <div class="it">
            <div class="h4 blue"><b>4</b></div>
            <div>Groups with less than 5 rooms will be subject to higher rates.</div>
        </div>
    </div>
</div>

<div class="join-e-club text-center mb-dynamic py-5">
    <div class="fixed">
        <h3>Request a no obligation proposal from our sales team and begin budgeting for a fantastic
            experience in Branson, Missouri.</h3>
        <div><a href="#" class="btn btn-secondary px-5">Planning a trip</a></div>
    </div>
</div>

<div class="fixed">
    <div class="row">
        <div class="col-md-6 mb-3">
            <h2>Meeting Spaces and Services</h2>
            Along with our main conference space of 760 square feet, our breakfast area has 760 square feet of space
            ideal for a meeting of any type and can be used any time after 1:00pm. Please contact our team for
            a proposal to include this meeting space.
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 mb-3">
            <h6 class="mb-3">Conference Room I</h6>
            <div class="text-center mb-3">
                <img src="/wp-content/themes/myerhospitality/assets/img/conference-room.jpg"/>
            </div>
            <div class="border-radius mb-5 me-xl-5">
                <div class="in">
                    <table class="style w-100">
                        <tbody>
                        <tr>
                            <td class="text-start">Dimensions:</td>
                            <td class="text-end">38′ x 20′</td>
                        </tr>
                        <tr>
                            <td class="text-start">Square footage:</td>
                            <td class="text-end">760</td>
                        </tr>
                        <tr>
                            <td class="text-start">Ceiling height:</td>
                            <td class="text-end">8′</td>
                        </tr>
                        <tr>
                            <td class="text-start">Theater style capacity:</td>
                            <td class="text-end">50</td>
                        </tr>
                        <tr>
                            <td class="text-start">Classroom style capacity:</td>
                            <td class="text-end">40</td>
                        </tr>
                        <tr>
                            <td class="text-start">Banquet style capacity:</td>
                            <td class="text-end">40</td>
                        </tr>
                        <tr>
                            <td class="text-start">U-shaped style capacity:</td>
                            <td class="text-end">20</td>
                        </tr>
                        <tr>
                            <td class="text-start">Click edit button to change this text.</td>
                            <td class="text-end"></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <img src="/wp-content/themes/myerhospitality/assets/img/conference-room-view.jpg" class="w-100 mb-3"/>
            <ul>
                <li><b>General Information:</b> both round and rectangular tables, table covers with skirting
                    for
                    buffet set up, podium, projector, screen, wireless high-speed Internet access, flip chart, white
                    board, flat screen TV, DVD player.
                </li>
                <li><b>Catering Services:</b> arranged upon request
                </li>
                <li>
                    <b>Contact:</b> Kathy Baltajy <a href="tel:888-837-2537"><b>888-837-2537</b></a>
                </li>
            </ul>
            <br/>
            <b>Alternate gathering/event spaces.</b>
            <ul>
                <li>Green spaces around our hotel for tented events; receptions, catered meals, etc.</li>
                <li>Patios for prayer groups, devotions, card games and more.</li>
            </ul>

        </div>
    </div>
    <div class="row mb-dynamic">
        <div class="col-md-6 mb-3">
            <h6 class="mb-3">Our Breakfast Room:</h6>
            <div class="text-center">
                <img src="/wp-content/themes/myerhospitality/assets/img/breakfast-room.jpg"/>
            </div>
        </div>
        <div class="col-md-6 mb-3">
            <img src="/wp-content/themes/myerhospitality/assets/img/breakfast-room-view.jpg" class="w-100"/>
        </div>
    </div>
</div>
<div class="fixed">
    <h2>Travel Resources</h2>
</div>
<div class="bg-gray-light py-3 mb-3">
    <div class="fixed">
        <a href="#" class="btn btn-primary me-md-3 mb-2">
            Transportation <span class="icon icon-arrow-right"></span>
        </a>
        <a href="https://bransonrestaurants.com/" target="_blank" class="btn btn-primary me-md-3 mb-2">
            Branson Restaurants <span class="icon icon-arrow-right"></span>
        </a>
        <a href="https://ibranson.com/" target="_blank" class="btn btn-primary me-md-3 mb-2">
            Shows & Attractions <span class="icon icon-arrow-right"></span>
        </a>
    </div>
</div>

<!-- wp:pattern {"slug":"myerhospitality/hotels-list-3"} /-->
<!-- wp:pattern {"slug":"myerhospitality/team"} /-->

