<?php

/**
 * Title: Awards
 * Slug: myerhospitality/awards
 * Categories: query, posts
 * Block Types: Awards
 */
$args = [
    'post_type'      => 'hotel',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
$arAwards = [];
$arHotels = [];
foreach ($posts as $post) {
    $arAwards[$post->ID] = [];
    $arHotels[$post->ID] = $post;
}
?>

<div class="fixed">
    <div class="mb-dynamic">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="blue pt-xl-5">
                    <b><?php the_title(); ?></b>
                </h1>
                <div class="me-lg-5 pe-lg-5">
                    <?php the_content(); ?>
                </div>
            </div>
            <div class="col-md-6 text-md-end text-center my-3 my-md-0">
                <?php foreach ($posts as $post) { ?>
                    <?php $smallLogo = wp_get_attachment_image_src(
                        get_post_meta($post->ID, 'small_logo', true),
                        'single-post-thumbnail'
                    );
                    if ($smallLogo) { ?>
                        <img src="<?= $smallLogo[0] ?>" alt="<?= $post->post_title ?>" class="mx-3"/>
                    <?php } ?>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<?php
$args = [
    'post_type'      => 'awards',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
foreach ($posts as $post) {
    $hotels = get_post_meta($post->ID, 'hotels', true);
    foreach ($hotels as $hotelId) {
        $arAwards[$hotelId][] = $post;
    }
}
?>
<?php $i = 0; ?>
<?php foreach ($arAwards as $id => $posts) { ?>
    <?php if ($posts) { ?>
        <div class="awards-list mb-dynamic">
            <div class="fixed">
                <h2><b><?= $arHotels[$id]->post_title ?></b></h2>
            </div>
            <div class="general-slide splide js-awards-list-splide js-awards-list-splide-<?= $i ?> splide-nav-up-right">
                <div class="splide__track">
                    <ul class="splide__list">
                        <?php foreach ($posts as $post) { ?>
                            <li class="splide__slide">
                                <?php $image = wp_get_attachment_image_src(
                                    get_post_thumbnail_id($post->ID),
                                    ['width' => 100, 'height' => 100]
                                );
                                ?>
                                <div class="img" style="background-image:url('<?= $image[0] ?>')">
                                    <img src="<?= $image[0] ?>"/>
                                </div>
                                <div class="name"><?= $post->post_title ?></div>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
        <?php $i++; ?>
    <?php } ?>
<?php } ?>
