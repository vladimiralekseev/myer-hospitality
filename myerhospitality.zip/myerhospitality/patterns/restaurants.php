<?php

/**
 * Title: Restaurants
 * Slug: myerhospitality/restaurants
 * Categories: query, posts
 * Block Types: Restaurants
 */
$args = [
    'post_type'      => 'restaurants',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
?>

<?php if ($posts) { ?>
    <div class="fixed">
        <h2><b>Myer Hospitality is Branson's top source for restaurant information</b></h2>
        <div class="guides mb-dynamic">
            <?php foreach ($posts as $post) { ?>
            <?php $url = get_post_meta($post->ID, 'url', true) ?>
            <?php $image = wp_get_attachment_image_src(
                get_post_thumbnail_id($post->ID),
                'single-post-thumbnail'
            ); ?>
            <div class="it">
                <?php if ($image) { ?>
                <a href="<?= $url ?>" target="_blank"><img src="<?= $image[0] ?>" alt="<?= $post->post_title ?>"/></a>
                <?php } ?>
                <a href="<?= $url ?>" target="_blank" class="h4 name mb-2"><?= $post->post_title ?></a>
                <div class="description mb-2"><?= $post->post_content ?></div>
                <?php if ($url) { ?>
                    <a href="<?= $url ?>" target="_blank" class="btn btn btn-third">View guide</a>
                <?php } ?>
            </div>
            <?php } ?>
        </div>
    </div>
<?php } ?>
<div class="join-e-club text-center mb-dynamic">
    <div class="fixed">
        <h2>Partner with Us for Advertising or Distribution</h2>
        <div class="mb-3">For further details about advertising opportunities or becoming a distribution location,
            please
            call us.</div>
        <div>
            <a href="tel:417-332-2378" class="btn btn-secondary me-2">417-332-2378</a>
            <a href="tel:417-334-6835" class="btn btn-secondary">417-334-6835</a>
        </div>
    </div>
</div>
<img src="/wp-content/themes/myerhospitality/assets/img/dining-2.jpg" class="w-100 mb-3"/>
<div class="bg-gray-light py-sm-5 py-4 mb-dynamic">
    <div class="fixed text-center text-sm-start">
        <h2 class="mb-sm-4">Featured Coupons from some of Branson’s Best Restaurants</h2>
        <div class="row align-items-center">
            <div class="col-sm-3 mb-3 mb-sm-0">
                <img src="/wp-content/themes/myerhospitality/assets/img/restaurant-coupons.png" />
            </div>
            <div class="col-xl-5 offset-xl-1 col-sm-6 mb-3 mb-sm-0">
                Get valuable coupons <br>
                at <a href="https://bransonrestaurants.com/deals/" target="_blank">Bransonrestaurants.com DEALS</a>.
            </div>
            <div class="col-sm-3">
                <a href="https://bransonrestaurants.com/deals/" target="_blank" class="btn btn-primary w-100">Get coupon</a>
            </div>
        </div>
    </div>
</div>
