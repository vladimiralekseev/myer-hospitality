<?php
/**
 * Title: Group Travel
 * Slug: myerhospitality/group-travel
 * Categories: query, posts
 * Block Types: Group Travel
 */


$posts = get_posts(
    [
        'post_type'      => 'group-travel',
        'orderby'        => 'menu_order',
        'order'          => 'ASC',
        'posts_per_page' => -1,
    ]
);
?>

<?php if ($posts) { ?>
    <?php foreach ($posts as $i => $post) { ?>
        <?php $imageIds = get_post_meta($post->ID, 'images', true); ?>
        <?php $images = get_posts(
            [
                'post_type' => 'attachment',
                'include'   => explode(',', $imageIds),
                'orderby'   => 'post__in',
            ]
        ); ?>
        <div class="mb-dynamic">
            <div class="<?= $i % 2 ? '' : 'bg-gray-light py-4' ?>">
                <div class="fixed">
                    <div class="row align-items-center">
                        <div class="col-md-6 <?= $i % 2 ? 'order-md-2' : '' ?>">
                            <?php if ($images) { ?>
                                <div class="gallery gallery-small mb-3 mb-md-0">
                                    <div class="splide js-gallery-splide">
                                        <div class="splide__track">
                                            <ul class="splide__list">
                                                <?php foreach ($images as $image) { ?>
                                                    <li class="splide__slide">
                                                        <div class="img"
                                                             style="background-image:url('<?= $image->guid ?>')">
                                                            <div class="container-data">
                                                                <img src="<?= $image->guid ?>"/>
                                                            </div>
                                                        </div>
                                                    </li>
                                                <?php } ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="splide-info js-splide-info">
                                        <div>1/12</div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="col-md-6 <?= $i % 2 ? 'order-md-1' : '' ?>">
                            <div class="mx-xl-5">
                                <h3 class="blue"><?= $post->post_title ?></h3>
                                <?= wpautop( $post->post_content ) ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>
