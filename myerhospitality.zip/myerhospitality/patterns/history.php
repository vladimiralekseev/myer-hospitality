<?php
/**
 * Title: History
 * Slug: myerhospitality/history
 * Categories: query, posts
 * Block Types: History
 */

$args = [
    'post_type'      => 'history',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
if ($posts) { ?>
    <div class="mb-dynamic">
        <div class="fixed">
            <h2>
                <b>Our History</b>
            </h2>
        </div>
        <div class="history">
            <?php foreach ($posts as $i => $post) { ?>
                <?php $image = wp_get_attachment_image_src(
                    get_post_thumbnail_id($post->ID),
                    'single-post-thumbnail'
                ); ?>
                <div class="it">
                    <div class="fixed">
                        <?php if ($i !== 0) { ?>
                            <?php if ($i % 2) { ?>
                                <h4 class="blue"><b><?= $post->post_title ?></b></h4>
                            <?php } else { ?>
                                <div class="row">
                                    <div class="offset-md-6 col-md-6">
                                        <h4 class="blue"><b><?= $post->post_title ?></b></h4>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } ?>
                        <div class="row">
                            <div class="col-md-6 <?= $i % 2 ? 'order-md-2' : '' ?>">
                                <?php if ($image) { ?>
                                    <img class="mb-3 mb-md-0" src="<?= $image[0] ?>"/>
                                <?php } ?>
                            </div>
                            <div class="col-md-6 <?= $i % 2 ? 'order-md-1' : '' ?>">
                                <?= apply_filters('the_content', $post->post_content) ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
<?php } ?>
