<?php
/**
 * Title: Packages
 * Slug: myerhospitality/home-packages
 * Categories: query, posts
 * Block Types: Packages
 */
$args = [
    'post_type'      => 'packages',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
if ($posts) {
    ?>
    <div class="fixed">
        <h2 class="mb-4"><b>Branson’s Best Vacation Packages</b></h2>
        <div class="packages-main js-packages-main">
            <?php foreach ($posts as $i => $post) { ?>
                <?php $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), [674, 480]); ?>
                <?php $url = get_post_meta($post->ID, 'url', true) ?>
                <?php $url = '/branson-tickets-packages/' //  target="_blank" ?>
                <?php $saveUpTo = get_post_meta($post->ID, 'save_up_to', true) ?>
                <?php $tags = get_the_tags($post); ?>
                <div class="it mb-5 js-it <?= $i >= 3 ? 'd-none' : '' ?>">
                    <div class="row">
                        <div class="col-md-5 col-12 mb-3">
                            <?php if ($image) { ?>
                                <?php if ($url) { ?>
                                    <a href="<?= $url ?>">
                                        <img src="<?= $image[0] ?>" alt="<?= $post->post_title ?>"/>
                                    </a>
                                <?php } else { ?>
                                    <img src="<?= $image[0] ?>" alt="<?= $post->post_title ?>"/>
                                <?php } ?>
                            <?php } ?>
                        </div>
                        <div class="col-md-7 col-12 mb-3">
                            <a href="<?= $url ?>"
                               class="d-block mb-2 h4"><b><?= $post->post_title ?></b></a>
                            <div>
                                <?= apply_filters('the_content', $post->post_content) ?>
                            </div>
                            <div class="my-lg-4 my-2">
                                <?php foreach ($tags as $tag) { ?>
                                    <span class="el-tag"><?= $tag->name ?></span>
                                <?php } ?>
                            </div>
                            <div class=" costs pt-lg-4 pt-2">
                                <div class="row align-items-center row-small-padding">
                                    <div class="col-7">
                                        <?php if ($saveUpTo) { ?>
                                            Save per adult <span class="up-to">up to <?= $saveUpTo ?></span>
                                        <?php } ?>
                                    </div>
                                    <?php if ($url) { ?>
                                        <div class="col-5 text-end">
                                            <a href="<?= $url ?>" class="btn btn-primary">Explore more</a>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
    <?php if (count($posts) > 3) { ?>
        <div class="packages-main-more mb-dynamic">
            <a class="btn btn-third js-more-packages">View more</a>
        </div>
    <?php } ?>
<?php } ?>
