<?php
/**
 * Title: Blog List
 * Slug: myerhospitality/blog-list
 * Categories: query, posts
 * Block Types: Blog List
 */
global $wpdb;
$currentPage = get_query_var('paged') ?: 1;
$currentCat = get_query_var('cat') ?: null;
$currentTag = get_query_var('tag') ?: null;
$s = $_GET['blog-search'] ?: null;

$query = new WP_Query(
    [
        'posts_per_page' => 10,
        'post_type'          => 'post',
        'paged'          => $currentPage,
        'cat'            => $currentCat,
        'tag'            => $currentTag,
        's'              => $wpdb->prepare($s),
    ]
);

?>

<div class="bg-blue py-4 mb-4">
    <div class="fixed">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1 class="white pt-2">
                    <b>Our Blog</b>
                </h1>
            </div>
            <div class="col-md-4">
                <!-- wp:pattern {"slug":"myerhospitality/blog-search"} /-->
            </div>
        </div>
    </div>
</div>
<div class="mb-dynamic">
    <div class="fixed">
        <div class="blog">
            <?php while ($query->have_posts()) {
                $query->the_post();
                $lint = get_permalink($post->ID);
                $tags = get_the_tags($post);
                $categories = get_the_category($post);
                $date = new DateTime($post->post_date);
                $categoriesArr = [];
                foreach ($categories as $category) {
                    $categoriesArr[] = '<a href="' . get_category_link($category) . '">' . $category->name . '</a>';
                }
                $tagsArr = [];
                if ($tags) {
                    foreach ($tags as $tag) {
                        $tagsArr[] = '<a href="' . get_tag_link($tag) . '">' . $tag->name . '</a>';
                    }
                } ?>
                <div class="post">
                    <div class="date py-5 text-center h6 d-none d-md-block">
                        <div><span class="icon icon-calendar"></span></div>
                        <?= $date->format('M d, Y') ?>
                    </div>
                    <div class="post-description">
                        <a href="<?= $lint ?>" class="name h2 fw-bold mb-2 d-block">
                            <?= the_title() ?>
                        </a>
                        <div class="d-md-none d-block mb-2">
                            <span class="icon icon-calendar"></span> <?= $date->format('M d, Y') ?>
                        </div>
                        <div class="fw-bold mb-2">
                            <?= implode(', ', $tagsArr) ?><?= $tagsArr ? ' | ' : '' ?>
                            <?= $date->format('M d, Y') ?><?= $categoriesArr ? ' | ' : '' ?>
                            <?= implode(', ', $categoriesArr) ?>
                        </div>
                        <div class="mb-3">
                            <?= get_the_excerpt($post) ?>
                        </div>
                        <a href="<?= $lint ?>" class="btn btn-third">Read more</a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<div class="posts-pagination mb-dynamic">
    <?= paginate_links(
        [
            'total'     => $query->max_num_pages,
            'current'   => $currentPage,
            'prev_text' => '<span class="icon icon-arrow-left"></span>',
            'next_text' => '<span class="icon icon-arrow-right"></span>',
        ]
    ) ?>
</div>
