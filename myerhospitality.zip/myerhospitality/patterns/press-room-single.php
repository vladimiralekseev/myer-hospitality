<?php
/**
 * Title: Press Room Single
 * Slug: myerhospitality/press-room-single
 * Categories: query, posts
 * Block Types: Press Room Single
 */
$post = get_post();
$file = wp_get_attachment_url(get_post_meta($post->ID, 'file', true));
if ($file) {
?>
<div class="mb-dynamic">
    <div class="fixed">
        <a href="<?= $file ?>" target="_blank"><b>Download Press Release</b></a>
    </div>
</div>
<?php } ?>
