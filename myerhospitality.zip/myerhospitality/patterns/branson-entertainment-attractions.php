<?php

/**
 * Title: Branson Entertainment & Attractions
 * Slug: myerhospitality/branson-entertainment-attractions
 * Categories: query, posts
 * Block Types: Branson Entertainment & Attractions
 */
$args = [
    'post_type'      => 'entertainment',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
$firstPosts = [];
$secondPosts = [];
foreach ($posts as $post) {
    $isFirst = get_post_meta($post->ID, 'is_first', true);
    if ($isFirst) {
        $firstPosts[] = $post;
    } else {
        $secondPosts[] = $post;
    }
}
?>

<div class="fixed">
    <?php if ($firstPosts) { ?>
        <div class="mb-dynamic">
            <h2 class="blue mb-md-5"><b>Branson: More than a destination, it’s an experience.</b></h2>
            <div class="experience">
                <?php foreach ($firstPosts as $post) { ?>
                    <?php $url = get_post_meta($post->ID, 'url', true) ?>
                    <?php $image = wp_get_attachment_image_src(
                        get_post_thumbnail_id($post->ID),
                        'single-post-thumbnail'
                    ); ?>
                    <div class="row">
                        <div class="col-3 d-xl-flex justify-content-between flex-column d-none mb-3">
                            <h4><b><?= $post->post_title ?></b></h4>
                            <?php if ($url) { ?>
                                <div>
                                    <a href="<?= $url ?>" target="_blank" class="btn btn-third px-5">More info</a>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="col-sm-4 mb-3">
                            <?php if ($image) { ?>
                                <img src="<?= $image[0] ?>" class="w-100 img-border" alt="<?= $post->post_title ?>"/>
                            <?php } ?>
                        </div>
                        <div class="col-xl-5 col-sm-8 mb-3">
                            <h4 class="d-block d-xl-none"><b><?= $post->post_title ?></b></h4>
                            <div class="mb-3"><?= $post->post_content ?></div>
                            <?php if ($url) { ?>
                                <div class="d-block d-xl-none">
                                    <a href="<?= $url ?>" target="_blank" class="btn btn-third px-5">More info</a>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    <?php } ?>

    <?php if ($secondPosts) { ?>
    <div class="mb-dynamic">
        <h2 class="blue mb-md-5"><b>Branson: Your Ultimate Adventure</b></h2>
        <div class="adventure">
            <?php foreach ($secondPosts as $post) { ?>
                <?php $url = get_post_meta($post->ID, 'url', true) ?>
                <?php $image = wp_get_attachment_image_src(
                    get_post_thumbnail_id($post->ID),
                    'single-post-thumbnail'
                ); ?>
            <div class="it">
                <div>
                    <a href="<?= $url ?>" target="_blank" class="img" style="background-image:url('<?= $image[0] ?>')">
                        <img src="" alt="<?= $post->post_title ?>"/>
                    </a>
                    <div class="name h6"><?= $post->post_title ?></div>
                    <div class="description"><?= $post->post_content ?></div>
                </div>
                <?php if ($url) { ?>
                    <a href="<?= $url ?>" target="_blank" class="btn btn-third w-100">More info</a>
                <?php } ?>
            </div>
            <?php } ?>
        </div>
    </div>
    <?php } ?>
</div>
<div class="join-e-club text-center mb-dynamic py-5">
    <div class="fixed">
        <h2 class="fw-normal">Branson Hospitality Starts with Myer</h2>
        <div>Explore Branson at its fullest with Myer Hospitality</div>
    </div>
</div>
