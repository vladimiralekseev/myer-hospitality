<?php

global $post;

$reserveRoom = (int)get_post_meta($post->ID, 'reserve_room_type', true);

if (!empty($_POST['hotelReserveRoom'])) {
    try {
        $checkIn = !empty($_POST['check-in']) ? new DateTime($_POST['check-in']) : new DateTime();
    } catch (Exception $e) {
        $checkIn = new DateTime();
    }
    try {
        $checkOut = !empty($_POST['check-out'])
            ? new DateTime($_POST['check-out']) : (new DateTime())->add(new DateInterval('P1D'));
    } catch (Exception $e) {
        $checkOut = (new DateTime())->add(new DateInterval('P1D'));
    }
    $guests = !empty($_POST['guests']) ? (int)$_POST['guests'] : 1;
    $rooms = !empty($_POST['rooms']) ? (int)$_POST['rooms'] : 1;
    $adults = !empty($_POST['adults']) ? (int)$_POST['adults'] : 1;
    $children = !empty($_POST['children']) ? (int)$_POST['children'] : 1;

    $action = '';
    if ($reserveRoom === 1) {
        $action = "http://book.bestwestern.com/bestwestern/selectRoom.do?propertyCode=26084"
            . "&numOfAdult=" . $guests . "&arrivalDay=" . $checkIn->format('d')
            . "&arrivalMonthYear=" . $checkIn->format('Ym')
            . "&departureDay=" . $checkOut->format('d')
            . "&departureMonthYear=" . $checkOut->format('Ym');
        header('Location: ' . $action);
        exit();
    } else if ($reserveRoom === 2) {
        $action = "https://www.choicehotels.com/missouri/branson/comfort-inn-hotels/mo610/rates?"
            . "adults=" . $adults
            . "&checkInDate=" . $checkIn->format('Y-m-d')
            . "&checkOutDate=" . $checkOut->format('Y-m-d')
            . "&minors=" . $children;
        header('Location: ' . $action);
        exit();
    } else if ($reserveRoom === 3) {
        $action = "https://www.choicehotels.com/missouri/branson/comfort-inn-hotels/mo068/rates?"
            . "adults=" . $adults
            . "&checkInDate=" . $checkIn->format('Y-m-d')
            . "&checkOutDate=" . $checkOut->format('Y-m-d')
            . "&minors=" . $children;
        header('Location: ' . $action);
        exit();
    } else if ($reserveRoom === 4) {
        $action = "https://www.ihg.com/holidayinnexpress/hotels/us/en/branson/brngm/hoteldetail"
            . "?fromRedirect=true&qSrt=sBR&qSlH=BRNGM"
            . "&qRms=" . $rooms . "&qAdlt=" . $adults . "&qChld=" . $children
            . "&qCiD=" . $checkIn->format('d')
            . "&qCiMy=" . $checkIn->format('mY')
            . "&qCoD=" . $checkOut->format('d')
            . "&qCoMy=" . $checkOut->format('mY')
            . "&setPMCookies=true&qSHBrC=EX&qDest=2801%20Green%20Mountain%20Drive%2C%20Branson%2C%20MO%2C%20US&srb_u=1";
        header('Location: ' . $action);
        exit();
    }
}
?>

<div class="reserve-room mb-dynamic py-5">
    <div class="fixed">
        <div class="h4 mb-4"><b>Reserve a room</b></div>

        <form method="post" target="_blank">
            <input type="hidden" name="hotelReserveRoom" value="<?= $reserveRoom ?>">
            <div class="row align-items-end">
                <div class="<?php if ($reserveRoom === 4) { ?>col-2<?php } else { ?>col-3<?php } ?>">
                    <label class="mb-2">Check In</label>
                    <input
                        class="wpcf7-form-control wpcf7-date wpcf7-validates-as-required wpcf7-validates-as-date wpcf7-res check-in-1"
                        id="check-in-1" min="2024-11-12" step="1" aria-required="true" aria-invalid="false"
                        placeholder="MM-DD-YYYY" value="2024-11-12" type="date" name="check-in"
                        data-gtm-form-interact-field-id="0">
                </div>
                <div class="<?php if ($reserveRoom === 4) { ?>col-2<?php } else { ?>col-3<?php } ?>">
                    <label class="mb-2">Check Out</label>
                    <input
                        class="wpcf7-form-control wpcf7-date wpcf7-validates-as-required wpcf7-validates-as-date wpcf7-res check-out-1"
                        id="check-out-1" min="2024-11-13" step="1" aria-required="true" aria-invalid="false"
                        placeholder="MM-DD-YYYY" value="2024-11-13" type="date" name="check-out"
                        data-gtm-form-interact-field-id="0">
                </div>
                <?php if ($reserveRoom === 1) { ?>
                    <div class="col-3">
                        <label class="mb-2">Guests</label>
                        <select name="guests">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                        </select>
                    </div>
                    <div class="col-3">
                        <button class="mb-1 py-2 btn btn-primary w-100">Book Hotel</button>
                    </div>
                <?php } ?>
                <?php if ($reserveRoom === 4) { ?>
                    <div class="col-2">
                        <label class="mb-2">Rooms</label>
                        <select name="rooms">
                            <option value="1" selected>1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                        </select>
                    </div>
                <?php } ?>
                <?php if (in_array($reserveRoom, [2, 3, 4], true)) { ?>
                    <div class="col-2">
                        <label class="mb-2">Adults</label>
                        <select name="adults">
                            <option value="1" selected>1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                        </select>
                    </div>
                    <div class="col-2">
                        <label class="mb-2">Children</label>
                        <select name="children">
                            <option value="0" selected>0</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                        </select>
                    </div>
                    <div class="col-2">
                        <button class="mb-1 py-2 btn btn-primary w-100">Book Hotel</button>
                    </div>
                <?php } ?>
            </div>
        </form>
    </div>
</div>
