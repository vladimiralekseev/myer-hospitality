<?php
/**
 * Title: Main Navigation
 * Slug: myerhospitality/main-navigation
 * Description: navigation.
 */
?>

<?php wp_nav_menu(['theme_location' => 'header-menu', 'menu_class' => 'menu-main']); ?>
