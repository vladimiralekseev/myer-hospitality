<?php
/**
 * Title: Main Navigation
 * Slug: myerhospitality/main-navigation
 * Description: navigation.
 */
?>

<?php wp_nav_menu($args = ['menu_class' => 'menu-main']); ?>
