<?php
/**
 * Title: Blog Search
 * Slug: myerhospitality/blog-search
 * Categories: query, posts
 * Block Types: Blog Search
 */
$s = $_GET['blog-search'] ?: null;
?>
<div class="white mb-1">Search by key words</div>
<form class="blog-search" method="get" action="/blog/">
    <input value="<?= esc_html($s) ?>" type="text" name="blog-search" class="w-100"
           placeholder="Type to search"/>
    <button type="submit"><span class="icon icon-search"></span></button>
</form>
