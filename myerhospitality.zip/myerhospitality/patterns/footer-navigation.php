<?php
/**
 * Title: Footer Navigation
 * Slug: myerhospitality/footer-navigation
 * Description: navigation.
 */
?>

<div class="row justify-content-sm-between flex-column flex-sm-row">
    <div class="col-sm-3 col-12">
        <div><b>Pages</b></div>
        <?php wp_nav_menu($args = ['theme_location' => 'footer-menu-1', 'menu_class' => '']); ?>
    </div>
    <div class="col-sm-3 col-12">
        <div><b>Terms</b></div>
        <?php wp_nav_menu($args = ['theme_location' => 'footer-menu-2', 'menu_class' => '']); ?>
    </div>
    <div class="col-sm-3 col-12">
        <div><b>Service</b></div>
        <?php wp_nav_menu($args = ['theme_location' => 'footer-menu-3', 'menu_class' => '']); ?>
    </div>
</div>
