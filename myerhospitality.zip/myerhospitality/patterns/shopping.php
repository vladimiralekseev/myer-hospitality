<?php

/**
 * Title: Shopping
 * Slug: myerhospitality/shopping
 * Categories: query, posts
 * Block Types: Shopping
 */
$args = [
    'post_type'      => 'shopping',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
?>

<?php if ($posts) { ?>
    <div class="fixed">
        <div class="mb-dynamic">
            <div class="adventure">
                <?php foreach ($posts as $post) { ?>
                    <?php $url = get_post_meta($post->ID, 'url', true) ?>
                    <?php $image = wp_get_attachment_image_src(
                        get_post_thumbnail_id($post->ID),
                        'single-post-thumbnail'
                    ); ?>
                    <div class="it">
                        <div>
                            <a href="<?= $url ?>" target="_blank" class="img"
                               style="background-image:url('<?= $image[0] ?>')">
                                <img src="<?= $image[0] ?>" alt="<?= $post->post_title ?>"/>
                            </a>
                            <div class="name h6"><?= $post->post_title ?></div>
                            <div class="description"><?= $post->post_content ?></div>
                        </div>
                        <?php if ($url) { ?>
                            <a href="<?= $url ?>" target="_blank" class="btn btn-third w-100">Explore</a>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
<div class="join-e-club text-center mb-dynamic py-5">
    <div class="fixed">
        <h2 class="fw-normal">Branson Hospitality Starts with Myer</h2>
        <div>Explore Branson at its fullest with Myer Hospitality</div>
    </div>
</div>
