<?php
/**
 * Title: Team
 * Slug: myerhospitality/team
 * Categories: query, posts
 * Block Types: Team
 */

$args = [
    'post_type'      => 'team',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
?>

<?php if ($posts) { ?>
    <div class="fixed">
        <h2 class="mb-4">Meet our Team</h2>
        <div class="row">
            <?php foreach ($posts as $post) { ?>
                <?php $phoneNumber = get_post_meta($post->ID, 'phone_number', true) ?>
                <?php $image = wp_get_attachment_image_src(
                    get_post_thumbnail_id($post->ID),
                    'single-post-thumbnail'
                ); ?>
                <div class="col-6 mb-dynamic">
                    <h3 class="blue mb-3"><?= $post->post_title ?></h3>
                    <div class="row">
                        <div class="col-4">
                            <?php if ($image) { ?>
                                <img src="<?= $image[0] ?>" class="w-100 mb-3 border-radius"
                                     alt="<?= $post->post_title ?>"/>
                            <?php } ?>
                            <?php if ($phoneNumber) { ?>
                                <a href="tel:<?= $phoneNumber ?>" class="btn btn-primary w-100"><?= $phoneNumber ?></a>
                            <?php } ?>
                        </div>
                        <div class="col-8">
                            <?= wpautop($post->post_content) ?>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
<?php } ?>
