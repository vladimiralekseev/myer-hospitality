<?php
/**
 * Title: Our mission
 * Slug: myerhospitality/our-mission
 * Categories: query, posts
 * Block Types: Our mission
 */

$args = [
    'post_type'      => 'our-mission',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
if ($posts) { ?>
    <div class="fixed">
        <h2><b>Our Mission</b></h2>
    </div>
    <div class="our-mission mb-dynamic">
        <div class="fixed">
            <div class="list">
                <?php foreach ($posts as $i => $post) { ?>
                    <?php $icon = get_post_meta($post->ID, 'icon', true) ?>
                    <div class="it">
                        <div class="it-up">
                            <span class="icon <?= $icon ?>"></span>
                            <div class="h4 title"><?= $post->post_title ?></div>
                        </div>
                        <?= apply_filters('the_content', $post->post_content) ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
