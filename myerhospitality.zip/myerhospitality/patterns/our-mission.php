<?php
/**
 * Title: Our mission
 * Slug: myerhospitality/our-mission
 * Categories: query, posts
 * Block Types: Our mission
 */

$args = [
    'post_type'      => 'our-mission',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
if ($posts) { ?>
    <div class="fixed">
        <h2><b>Our Mission — Friendly, Fantastic Service Always</b></h2>
    </div>
    <div class="our-mission mb-dynamic">
        <div class="fixed">
            <div class="list">
                <?php foreach ($posts as $i => $post) { ?>
                    <div class="it">
                        <div class="it-up">
                            <div class="h4 title"><?= $post->post_title ?></div>
                        </div>
                        <div class="it-down">
                            <?= apply_filters('the_content', $post->post_content) ?>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>
