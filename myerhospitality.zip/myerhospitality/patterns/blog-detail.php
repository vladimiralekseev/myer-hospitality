<?php
/**
 * Title: Blog Detail
 * Slug: myerhospitality/blog-detail
 * Categories: query, posts
 * Block Types: Blog Detail
 */
global $post;
$tags = get_the_tags($post);
$categories = get_the_category($post);
$date = new DateTime($post->post_date);
$categoriesArr = [];
foreach ($categories as $category) {
    $categoriesArr[] = '<a href="' . get_category_link($category) . '">' . $category->name . '</a>';
}
$tagsArr = [];
if ($tags) {
    foreach ($tags as $tag) {
        $tagsArr[] = '<a href="' . get_tag_link($tag) . '">' . $tag->name . '</a>';
    }
}
?>
<div class="bg-blue py-4 mb-4">
    <div class="fixed">
        <div class="row align-items-center">
            <div class="col-md-8">
                <div class="navigation d-none d-md-block">
                    <a href="/our-history/">About Myer</a> <span class="icon icon-arrow-next"></span>
                    <a href="/blog/">Our Blog </a> <span class="icon icon-arrow-next"></span>
                    <span class="current"><?= $post->post_title ?></span>
                </div>
            </div>
            <div class="col-md-4">
                <!-- wp:pattern {"slug":"myerhospitality/blog-search"} /-->
            </div>
        </div>
    </div>
</div>
<div class="mb-dynamic">
    <div class="fixed">
        <div class="blog">
            <div class="post">
                <div class="date py-5 text-center h6 d-none d-md-block">
                    <div><span class="icon icon-calendar"></span></div>
                    <?= $date->format('M d, Y') ?>
                </div>
                <div class="post-description">
                    <h1 class="name h2 fw-bold mb-2 d-block"><?= $post->post_title ?></h1>
                    <div class="d-md-none d-block mb-2">
                        <span class="icon icon-calendar"></span> <?= $date->format('M d, Y') ?>
                    </div>
                    <div class="fw-bold mb-2">
                        <?= implode(', ', $tagsArr) ?><?= $tagsArr ? ' | ' : '' ?>
                        <?= $date->format('M d, Y') ?><?= $categoriesArr ? ' | ' : '' ?>
                        <?= implode(', ', $categoriesArr) ?>
                    </div>
                    <div class="mb-3">
                        <?= $post->post_content ?>
                    </div>
                    <div class="row">
                        <div class="col-md-6"></div>
                        <div class="col-md-6 text-md-end text-center pb-5">
                            <?= get_the_post_navigation(['prev_text' => 'Previous post', 'next_text' => 'Next post']) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
