<?php
/**
 * Title: Best Service
 * Slug: myerhospitality/home-best-service
 * Categories: query, posts
 * Block Types: Best Service
 */

$args = [
    'post_type'      => 'best-service',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);
?>
<div class="fixed">
    <h2><b>Experience Exceptional Service</b></h2>
    <div class="services mb-dynamic">
        <?php foreach ($posts as $post) { ?>
            <?php
            $image = wp_get_attachment_image_src(
                get_post_thumbnail_id($post->ID),
                'single-post-thumbnail'
            );
            if ($image) { ?>
                <div class="it">
                    <img src="<?= $image[0] ?>" alt="<?= $post->post_title ?>"/>
                    <div><?= $post->post_title ?></div>
                </div>
            <?php } ?>
        <?php } ?>
    </div>
</div>
