<?php
/**
 * Title: Hotels Small List
 * Slug: myerhospitality/hotels-small-list
 * Categories: query, posts
 * Block Types: Hotel
 */

$args = [
    'posts_per_page' => 4,
    'post_type'      => 'hotel',
];
$posts = get_posts($args);
?>
    <div class="fixed">
        <div class="small-hotels mb-dynamic">
            <?php foreach ($posts as $post) { ?>
                <?php $link = get_permalink($post->ID) ?>
                <?php $phoneNumber = get_post_meta($post->ID, 'phone_number', true) ?>
                <?php $image = wp_get_attachment_image_src(
                    get_post_meta($post->ID, 'preview_image', true),
                    'single-post-thumbnail'
                ); ?>
                <div class="it">
                    <?php if ($image) { ?>
                        <a href="<?= $link ?>"><img src="<?= $image[0] ?>" alt="<?= $post->post_title ?>"/></a>
                    <?php } ?>
                    <a href="<?= $link ?>" class="h5 name mb-2"><?= $post->post_title ?></a>
                    <?php if ($phoneNumber) { ?>
                        <div class="btns">
                            <a href="tel:<?= $phoneNumber ?>" class="btn btn btn-third"><?= $phoneNumber ?></a>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
    </div>
<?php
wp_reset_postdata();

