<?php

/**
 * Title: Customer Service
 * Slug: myerhospitality/customer-service
 * Categories: query, posts
 * Block Types: Customer Service
 */
$args = [
    'post_type'      => 'customer-service',
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
    'posts_per_page' => -1,
];
$posts = get_posts($args);

?>
<h1 class="fixed blue pt-xl-5 mb-dynamic">
    <b><?php the_title(); ?></b>
</h1>
<div class="fixed mb-dynamic">
    <div class="row">
        <?php foreach ($posts as $post) { ?>
            <div class="col-xl-4 col-sm-6">
                <div class="fw-bold"><?= $post->post_title ?></div>
                <div class="mb-md-4 mb-3"><?= apply_filters('the_content', $post->post_content) ?></div>
            </div>
        <?php } ?>
    </div>
</div>
<div class="mb-dynamic">
    <?php the_content(); ?>
</div>
<div class="mb-dynamic">
    <img src="/wp-content/themes/myerhospitality/assets/img/map.png" class="w-100">
</div>

