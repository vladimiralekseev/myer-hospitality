<?php
/**
 * Title: Real Estate
 * Slug: myerhospitality/real-estate
 * Categories: query, posts
 * Block Types: Real Estate
 */

$args = [
    'post_type'      => 'real-estate-images',
    'orderby'        => 'date',
    'order'          => 'DESC',
    'posts_per_page' => -1,
];
$realEstateImages = get_posts($args);
?>
<div class="fixed">
    <div class="lake-list mb-dynamic">
        <div class="row">
            <div class="col-6">
                <img src="/wp-content/themes/myerhospitality/assets/img/lake-1.jpg" class="w-100 mb-3" />
                <h4>Lake View & Lakefront Estate Lots</h4>
                <div>Our master-planned gated community has wooded estate lots with underground utilities, curb and guttering, ornamental street lights, landscaping, architectural covenants and restrictions.</div>
            </div>
            <div class="col-6">
                <img src="/wp-content/themes/myerhospitality/assets/img/lake-2.jpg" class="w-100 mb-3" />
                <h4>Lake View Town Homes</h4>
                <div>Two-story whole-ownership townhouses are under construction. Enjoy beautiful lake views, 2300 sq. feet of livable space and two-car garage.</div>
            </div>
        </div>
    </div>
</div>
<img src="/wp-content/themes/myerhospitality/assets/img/real-estate.jpg" class="w-100 mb-3"/>
<div class="bg-gray-light py-sm-5 py-4 mb-dynamic">
    <div class="fixed text-center text-sm-start">
        <h2 class="mb-sm-4">Luxury Lakeside Living</h2>
        <div class="row align-items-center">
            <div class="col-sm-3 mb-3 mb-sm-0">
                <img src="/wp-content/themes/myerhospitality/assets/img/whispered-cove-small.jpg" />
            </div>
            <div class="col-xl-5 offset-xl-1 col-sm-6 mb-3 mb-sm-0">
                Lot sizes average more than half an acre for residential estates. Mountain villas are now
                available for purchase. For more information, contact <b><a href="tel:417-334-6835">Chris Myer <br>
                        at 417-334-6835</a></b>.
            </div>
            <div class="col-sm-3">
                <a href="/wp-content/themes/myerhospitality/assets/whisper-cove-map.pdf" class="btn btn-primary w-100">Download map</a>
            </div>
        </div>
    </div>
</div>
<div class="fixed">
    <div class="row align-items-center mb-dynamic">
        <div class="col-md-6 mb-3">
            <div class="gallery gallery-small">
                <div class="splide js-gallery-splide">
                    <div class="splide__track">
                        <ul class="splide__list">
                            <?php foreach ($realEstateImages as $i => $img) { ?>
                            <?php $image = wp_get_attachment_image_src(
                                get_post_thumbnail_id($img->ID),
                                'single-post-thumbnail'
                            ); ?>
                            <?php if ($image) { ?>
                            <li class="splide__slide" data-img="img/hotel-cpi.jpg">
                                <div class="img" style="background-image:url('<?= $image[0] ?>')">
                                    <div class="container-data">
                                        <img src="<?= $image[0] ?>"/>
                                    </div>
                                </div>
                            </li>
                            <?php } ?>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
                <div class="splide-info js-splide-info">
                    <div>1/12</div>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-3">
            <h2 class="blue">Whisper Cove Luxury Lakeside Living in Branson</h2>
            <div>
                Whisper Cove is a gated community with features like underground utilities, curb and guttering, ornamental street lights, landscaping, architectural covenants and restrictions.
            </div>
        </div>
    </div>
</div>
<div class="fixed">
    <div class="row">
        <div class="col-sm-6 mb-dynamic">
            <div class="green mb-3"><b>Exterior Details:</b></div>
            <ul class="style">
                <li>Beautiful Lake Views</li>
                <li>Table Rock Lake access approved with boat ramp, courtesy dock, and dry dock storage space planned</li>
                <li>Fantastic landscaping</li>
                <li>Major fountain display and roundabout</li>
            </ul>
        </div>
        <div class="offset-xl-1 col-sm-6 col-xl-5 mb-dynamic">
            <div class="green mb-3"><b>Additional Details:</b></div>
            <ul class="style">
                <li>Central Sewer / Water</li>
                <li>Strong Covenants for Property Protection</li>
                <li>Branson School District</li>
                <li>Gated Community</li>
            </ul>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 mb-dynamic">
            <div class="border-radius">
                <div class="in">
                    <table class="style w-100">
                        <thead>
                        <tr>
                            <th><strong>Lot #</strong></th>
                            <th><strong>Size / Acres</strong></th>
                            <th><strong>Lot Prices</strong></th>
                        </tr>
                        </thead>
                        <tbody class="style w-100">
                        <tr>
                            <td>1</td>
                            <td>.86</td>
                            <td>104,999</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>.61</td>
                            <td>&nbsp;89,999</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>.85</td>
                            <td>134,999</td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>.62</td>
                            <td>&nbsp;89,999</td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td>.65</td>
                            <td>&nbsp;99,999</td>
                        </tr>
                        <tr>
                            <td>8</td>
                            <td>.64</td>
                            <td>&nbsp;89,999</td>
                        </tr>
                        <tr>
                            <td>9</td>
                            <td>.79</td>
                            <td>149,999</td>
                        </tr>
                        <tr>
                            <td>10</td>
                            <td>.87</td>
                            <td>&nbsp;69,999</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-6 mb-dynamic">
            <p>Branson’s most exclusive lakefront development can’t be beat. Located in the Branson School
                District and only a hop, skip and jump away from Branson’s entertainment simply make Whisper Cove’s location incredible. Lot prices are a great value for this prime property location.
            </p>
            <p>
                Mountain villas are now available for purchase. Pre-construction pricing beginning at $329,000
                per townhome.
            </p>
            <p>
                For more information, <a href="tel:417-334-6835"><b>contact Chris Myer at 417-334-6835</b></a>.
            </p>
            <p>
                Whisper Cove is owned by the Myer family, a long-time hospitality and entertainment company
                based in Branson, Mo.
            </p>
        </div>
    </div>
</div>
<div class="join-e-club text-center mb-dynamic py-5">
    <div class="fixed">
        <h2 class="fw-normal">Branson Hospitality Starts with Myer</h2>
        <div>Explore Branson at its fullest with Myer Hospitality</div>
    </div>
</div>
