<?php
/**
 * Title: Page Top
 * Slug: myerhospitality/page-top
 * Categories: query, posts
 * Block Types: Page
 */

/** @var WP_Post $post */
$post = get_post();
$youtubeEmbedLink = get_post_meta($post->ID, 'youtube_embed_link', true);
$image = wp_get_attachment_image_src(
    get_post_thumbnail_id($post->ID),
    'single-post-thumbnail'
); ?>


<div class="fixed">
    <div class="mb-dynamic">
        <?php if ($youtubeEmbedLink || $image) { ?>
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="blue pt-xl-5">
                        <b><?php the_title(); ?></b>
                    </h1>
                    <div class="me-lg-5 pe-lg-5">
                        <?php the_content(); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <?php if ($image) { ?>
                        <img class="border-radius" src="<?= $image[0] ?>" alt="<?php the_title(); ?>"/>
                    <?php } elseif ($youtubeEmbedLink) { ?>
                        <iframe class="history-youtube w-100" src="<?= $youtubeEmbedLink ?>"
                                title="YouTube video player" frameborder="0"
                                allow="accelerometer; clipboard-write; encrypted-media; gyroscope; web-share"
                                allowfullscreen></iframe>
                    <?php } ?>
                </div>
            </div>
        <?php } else { ?>
            <h1 class="blue pt-xl-5">
                <b><?php the_title(); ?></b>
            </h1>
            <div class="me-lg-5 pe-lg-5">
                <?php the_content(); ?>
            </div>
        <?php } ?>
    </div>
</div>
