<!DOCTYPE html>
<html lang="en-US" itemscope itemtype="http://schema.org/WebPage">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:title" content="MyerHospitality"/>
    <meta property="og:type" content="website"/>
    <meta property="og:url" content="https://myerhospitality.com/"/>
    <title><?php wp_title(); ?></title>
    <link href="/favicon.ico" rel="shortcut icon" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500;" rel="stylesheet">
    <?php wp_enqueue_style('style', get_template_directory_uri() . '/assets/css/main.css'); ?>
    <?php wp_enqueue_style('style', get_template_directory_uri() . '/assets/fonts/mh/styles.css'); ?>
    <?php wp_head(); ?>
</head>
<body>
<div class="wrapper-main">
    <header>
        <div class="fixed">
            <div class="header-container">
                <div>
                    <a href="/">
                        <img src="<?= get_template_directory_uri() . '/assets/img/myer-hospitality-logo.png' ?>"
                             alt="MyerHospitality" class="logo"/>
                    </a>
                </div>
                <div>
                    <?php wp_nav_menu($args = ['menu_class' => 'menu-main']); ?>
                </div>
                <div><a class="btn btn-primary d-md-inline-block d-none" href="#">Book now</a></div>
                <div>
                    <a id="menu-up-control" class="menu-up-control menu-up-control-is-close">
                        <span class="icon icon-menu"></span><span class="icon icon-x"></span>
                    </a>
                </div>
            </div>
        </div>
    </header>
