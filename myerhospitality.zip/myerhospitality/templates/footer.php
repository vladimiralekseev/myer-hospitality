<footer>
    <div class="fixed">
        <div class="row py-4">
            <div class="col-md-4 col-12 mb-md-0 mb-3">
                <div class="row align-items-center">
                    <div class="col-sm-4 col-md-12 col-12 mb-3 text-sm-start text-center">
                        <a href="#"><img class="footer-logo" src="<?= get_template_directory_uri(
                            ) . '/assets/img/myer-hospitality-logo.png' ?>"/></a>
                    </div>
                    <div class="col-sm-4 col-md-12 col-6 my-md-4 mb-3 text-md-start text-sm-center text-start">
                        <a href="#" class="me-2"><img
                                    src="<?= get_template_directory_uri() . '/assets/img/twitter.png' ?>"/></a>
                        <a href="#"><img src="<?= get_template_directory_uri() . '/assets/img/facebook.png' ?>"/></a>
                    </div>
                    <div class="col-sm-4 col-md-12 col-6 mb-3 text-md-start text-end">
                        <a href="#" class="btn btn-primary">Contact us</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8 col-12">
                <div class="row justify-content-sm-between flex-column flex-sm-row">
                    <div class="col-sm-3 col-12">
                        <div><b>Pages</b></div>
                        <ul>
                            <li><a href="#">About Myer</a></li>
                            <li><a href="#">Our hotels</a></li>
                            <li><a href="#">Travel & Entertainment</a></li>
                            <li><a href="#">Dining</a></li>
                            <li><a href="#">Real Estate</a></li>
                            <li><a href="#">Group Travel & Meeting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3 col-12">
                        <div><b>Terms</b></div>
                        <ul>
                            <li><a href="#">Privacy Statement</a></li>
                            <li><a href="#">Terms of use</a></li>
                            <li><a href="#">Sitemap</a></li>
                            <li><a href="#">Tell us how we did</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-3 col-12">
                        <div><b>Service</b></div>
                        <ul>
                            <li><a href="#">Press room</a></li>
                            <li><a href="#">Join our e-club</a></li>
                            <li><a href="#">Careers</a></li>
                            <li><a href="#">News</a></li>
                            <li><a href="#">Traveling with family</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

</div>
