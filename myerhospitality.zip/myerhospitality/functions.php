<?php
function mytheme_enqueue_style() {
    wp_enqueue_style ('bootstrap-style','https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css');
    wp_enqueue_style ('fonts-style','https://fonts.googleapis.com/css?family=Poppins:400,500;');
    wp_enqueue_style( 'main-style', get_stylesheet_uri() );
    wp_enqueue_style ('splide-style',get_template_directory_uri().'/assets/css/splide.min.css');
    wp_enqueue_style ('icon-style',get_template_directory_uri().'/assets/fonts/mh/styles.css');
    wp_enqueue_script('jquerymy', 'https://code.jquery.com/jquery-3.7.1.min.js', [], '', true);
    wp_enqueue_script(
        'bootstrap-bundle',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js',
        [],
        '',
        true
    );
    wp_enqueue_script('splide', get_template_directory_uri() . '/assets/js/splide.min.js', [], '', true);
    wp_enqueue_script('main', get_template_directory_uri() . '/assets/js/main.js', [], '', true);
    wp_enqueue_script('sliders', get_template_directory_uri() . '/assets/js/sliders.js', [], '', true);

    wp_enqueue_style( 'admin-custom', get_stylesheet_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'mytheme_enqueue_style' );

function wpb_custom_new_menu() {
    register_nav_menu('header-menu', 'Header');
    register_nav_menu('footer-menu-1', 'Footer 1');
    register_nav_menu('footer-menu-2', 'Footer 2');
    register_nav_menu('footer-menu-3', 'Footer 3');
    register_nav_menu('request-menu', 'Request');
}
add_action( 'init', 'wpb_custom_new_menu' );


function register_post_types() {
    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-format-gallery',
        'label'  => 'Main Slider',
        'supports' => ['title', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'main-slider', $args );

    $args = [
        'public' => true,
        'menu_icon' => 'dashicons-building',
        'label'  => 'Hotels',
//        'register_meta_box_cb' => 'register_meta_box',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'hotel', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-building',
        'label'  => 'Hotels Rooms',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'rooms', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-building',
        'label'  => 'Hotels Reviews',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'reviews', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-editor-ul',
        'label'  => 'History',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'history', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-universal-access',
        'label'  => 'Our mission',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'our-mission', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'label'  => 'Press room',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'press-room', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-awards',
        'label'  => 'Awards',
        'supports' => ['title', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'awards', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-star-filled',
        'label'  => 'Best service',
        'supports' => ['title', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'best-service', $args );

    $args = [
        'public' => true,
        'menu_icon' => 'dashicons-portfolio',
        'label'  => 'Packages',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'packages', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-media-document',
        'label'  => 'Guides',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'guides', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-buddicons-groups',
        'label'  => 'Entertainment',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'entertainment', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-products',
        'label'  => 'Shopping',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'shopping', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-store',
        'label'  => 'Restaurants',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'restaurants', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-format-gallery',
        'label'  => 'Real Estate Images',
        'supports' => ['title', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'real-estate-images', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-admin-site',
        'label'  => 'Group Travel',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'group-travel', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-groups',
        'label'  => 'Team',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'team', $args );

    $args = [
        'public' => true,
        'has_archive' => false,
        'publicly_queryable' => false,
        'query_var ' => false,
        'menu_icon' => 'dashicons-admin-multisite',
        'label'  => 'Customer Service',
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
    ];
    register_post_type( 'customer-service', $args );
}
add_action( 'init', 'register_post_types' );

add_image_size('j0e_admin-featured-image', 60, 60, false);
add_filter('manage_main-slider_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_hotel_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_history_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_awards_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_packages_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_guides_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_rooms_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_reviews_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_entertainment_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_shopping_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_restaurants_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_real-estate-images_posts_columns', 'j0e_add_thumbnail_column', 2);
add_filter('manage_team_posts_columns', 'j0e_add_thumbnail_column', 2);
function j0e_add_thumbnail_column($j0e_columns)
{
    $j0e_columns['j0e_thumb'] = __('Image');
    return $j0e_columns;
}

add_action('manage_main-slider_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_hotel_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_history_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_awards_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_packages_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_guides_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_rooms_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_reviews_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_entertainment_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_shopping_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_restaurants_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_real-estate-images_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
add_action('manage_team_posts_custom_column', 'j0e_show_thumbnail_column', 5, 2);
function j0e_show_thumbnail_column($j0e_columns, $j0e_id)
{
    switch ($j0e_columns) {
        case 'j0e_thumb':
            if (function_exists('the_post_thumbnail')) {
                echo the_post_thumbnail('j0e_admin-featured-image');
            }
            break;
    }
}

//function register_meta_box() {
//    add_meta_box(
//        'hotelAttributes',
//        'Hotel Attributes',
//        'testimonial_meta_html',
//        'hotel'
//        'side'
//    );
//}
//
//function testimonial_meta_html()
//{
//    global $post;
//    $nonce_key = 'testimonial_fields_nonce';
//
//    wp_nonce_field($nonce_key, $nonce_key);
//
//    $value = get_post_meta($post->ID, 'phone_number', true);
//    echo '<p class="post-attributes-label-wrapper menu-order-label-wrapper"><label class="post-attributes-label">Phone Number</label></p>';
//    echo '<input type="text" id="phone_number" name="phone_number" class="widefat" value="' . $value . '">';
//
//    $value = get_post_meta($post->ID, 'address', true);
//    echo '<p class="post-attributes-label-wrapper menu-order-label-wrapper"><label class="post-attributes-label">Address</label></p>';
//    echo '<input type="text" id="address" name="address" class="widefat" value="' . $value . '">';
//}
//
//function save_testimonial_meta($post_id, $post)
//{
//    $nonce_key = 'testimonial_fields_nonce';
//    if (!isset($_POST[$nonce_key]) || !wp_verify_nonce($_POST[$nonce_key], $nonce_key)) {
//        return 'nonce not verified';
//    }
//    if (wp_is_post_autosave($post_id)) {
//        return 'autosave';
//    }
//    if (wp_is_post_revision($post_id)) {
//        return 'revision';
//    }
//    if (!current_user_can('edit_post', $post_id)) {
//        return 'cannot edit post';
//    }
//    update_post_meta($post_id, 'phone_number', $_POST['phone_number']);
//    update_post_meta($post_id, 'address', $_POST['address']);
//}
//
//add_action('save_post', 'save_testimonial_meta', 10, 2);
//https://www.bestwestern.com/content/best-western/en_US/booking-path/hotel-details.26084.html?propertyCode=26084&numOfAdult=1&arrivalDay=17&arrivalMonthYear=202410&departureDay=24&departureMonthYear=202410
//https://www.bestwestern.com/content/best-western/en_US/booking-path/hotel-details.26084.html?propertyCode=26084&numOfAdult=6&arrivalDay=12&arrivalMonthYear=202410&departureDay=15&departureMonthYear=202410
//https://www.choicehotels.com/missouri/branson/comfort-inn-hotels/mo068/rates?checkInDate=2024-11-12&checkOutDate=2024-11-13
//https://www.choicehotels.com/missouri/branson/comfort-inn-hotels/mo068/rates?checkInDate=2024-11-12&checkOutDate=2024-11-13&adults=2&minors=2&rooms=2
//https://www.ihg.com/holidayinnexpress/hotels/us/en/branson/brngm/hoteldetail?fromRedirect=true&qSrt=sBR&qSlH=BRNGM&qRms=1&qAdlt=1&qChld=0&qCiD=28&qCiMy=102024&qCoD=29&qCoMy=102024&setPMCookies=true&qSHBrC=EX&qDest=2801%20Green%20Mountain%20Drive%2C%20Branson%2C%20MO%2C%20US&srb_u=1
