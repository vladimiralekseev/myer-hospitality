
<?php include get_template_directory() . '/templates/header.php';?>
<main>
<?php the_content() ?>
</main>
<?php include get_template_directory() . '/templates/footer.php';?>
